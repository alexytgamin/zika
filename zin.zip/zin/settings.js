const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false //auto kick spammer (true to on, false to off)
//===============SETTING MENU==================\\
global.thumbnail = fs.readFileSync("./data/image/thumb.jpg")
global.ig = '@Nothing'
global.yt = '@Nothing'
global.ttowner = '@Nothing'
global.ownername = 'zexs'
global.owner = ['6285389296108'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6285389296108'
global.socialm = 'GitHub: xynn9'
global.location = 'Singapore' 
//========================setting Payment=====================\\
global.nodana = '6285389296108' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '6285389296108' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '6285389296108' // KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = '6289516636775' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '6289516636775' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '6289516636775' // KOSONG KAN JIKA TIDAK ADA
//==================setting bot===========================\\
global.botname = "zexs - MD"
global.ownernumber = '6285389296108'
global.botnumber = '6282128959137'
global.ownername = 'zexs'
global.ownerNumber = ["6285389296108@s.whatsapp.net"]
global.ownerweb = "@Nothing"
global.websitex = "@Nothing"
global.wagc = "https://chat.whatsapp.com/J9c0BNT0S4qCXaUvSGyaGW"
global.saluran = "https://whatsapp.com/channel/0029VarwY6UJZg41iocQhj17"
global.idch = "@newsletter"
global.themeemoji = '🪀'
global.wm = "zexs"
global.botscript = '@Nothing' //script link
global.packname = "Sticker By"
global.author = "\n\n\n\n\nsticker di buat oleh bot\nno bot Zexs - MD"
global.creator = "6289667644225@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
global.domain = 'https://dwiz-host.rkhosttting.xyz' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_0lx5Cnvsq5pwlNDbZeZLRhWfwIPm5cYmOLHYyiXxBXr' // Isi Apikey Plta Lu
global.capikey = 'ptlc_pknMEhjBkC2TLwDsSXZODWLjDR5gz5PgWjpYfdRbrIH' // Isi Apikey Pltc Lu
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah

global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//

global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['!']
global.sessionName = 'sessions'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
wait: "sabar ya",
   success: "sukses ya ngab",
   on: "udah on kontol", 
   off: "off kontol",
   query: {
       text: "text nya mana tolol",
       link: "link nya mana tolol",
   },
   error: {
       fitur: "fitur nya error chat aja developer yang bikin sc",
   },
   only: {
       group: "khusus di group tolol",
       private: "khusus di private chat tolol",
       owner: "khusus owner bot",
       admin: "khusus admin group",
       badmin: "bkt perlu jadi admin",
       premium: "beli kocak lu kira gratis cuma 10k udah dapat premium",
   }
}
 
//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "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"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
