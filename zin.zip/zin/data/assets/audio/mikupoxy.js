{
	"name": "Cheems Bot Multi Device "
}


case 'play': case 'songs': {
 reply(mess.wait)
let yts = require("yt-search")
if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
try {
let search = await yts(text);
let anup3k = search.videos[0];
let { title, thumbnail, timestamp, views, ago, url } = anup3k;
let procees = await (await fetch(`https://widipe.com/download/ytdl?url=${url}`)).json()
             let doc = { 
    audio: {
      url: procees.result.mp3
    },
    mimetype: 'audio/mp4',
    fileName: `${title}`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 2,
        mediaUrl: url,
        title: title,
        sourceUrl: url,
        thumbnail: await (await mikupoxy.getFile(thumbnail)).data
      }
    }
  }
  await mikupoxy.sendMessage(m.chat, doc, { quoted: m });
} catch (e) {
    reply('*terjadi error :*' + e)
}
}
break